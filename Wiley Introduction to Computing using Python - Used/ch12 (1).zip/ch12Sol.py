# Problem 12.16
from sqlite3 import connect
def ranking(db):
    '''db is a database file that contains table Hyperlinks with columns Url
       and Link.

       function adds to db new table Rank that contains the number of incoming
       hyperlinks (i.e. Hyperlink table records) for every URL listed in the
       Link column of Hyperlinks.
    '''
    con = connect(db)
    cur = con.cursor()
    cur.execute("CREATE TABLE Ranks (Url text, Rank int)")
    cur.execute("SELECT Link, COUNT(*) FROM Hyperlinks GROUP BY Link")
    for record in cur:
        print(record)
        cur.execute('INSERT INTO Ranks VALUES (?,?)', record)
    con.commit()
    con.close()



# Problem 12.17
from sqlite3 import connect
from re import findall
def words(filename, db):
    '''computes the frequency of words in file filename and stores
       word, frequency pairs in a new database file named db with
       columns Word and Freq
    '''
    # get file content
    infile = open(filename)
    content = infile.read()
    infile.close()

    # collect all words with 3 or more characters into a list
    pattern = '[A-Za-z][A-Za-z][A-Za-z\-\']+'
    wordList = findall(pattern, content)

    # count word frequencies
    d = {}
    for word in wordList:
        word = word.lower()
        if word in d:
            d[word] += 1
        else:
            d[word] = 1

    # record word frequencies in a database 
    con = connect(db)
    c = con.cursor()
    # Create table
    c.execute('create table if not exists Wordcount(Word varchar, Freq int)')
    for word in d:
        c.execute('insert into Wordcount values (?,?)', (word, d[word]))
    c.execute('select * from Wordcount order by word asc')
    for record in c.fetchall():
        print(record)
    con.commit()
    con.close()



# Problem 12.18
def jump(t, x, y):
    'makes turtle t jump to coordinates (x,y)'
    t.penup()
    t.goto(x,y)
    t.pendown()

from random import randrange
from sqlite3 import connect
from turtle import Screen, Turtle
def draw(db, n):
    '''db is a database file containing table Wordcount with columns Word
       and Freq (storing the frequency of words in some document)
       
       function uses turtle to draw a basic word cloud out of the n most
       frequently occuring words 
    '''
    # open database file and select n most frequently occuring words
    con = connect(db)
    c = con.cursor()
    c.execute('select Word from Wordcount order by Freq desc limit 0,?',(n,))

    # write the n words onto a turtle Screen
    s = Screen()
    t = Turtle()
    for record in c.fetchall():
        x = randrange(-300, 301)
        y = randrange(-300, 301)
        jump(t, x, y)
        t.write(record[0], font=('Arial', 40, 'bold'))
    input('Press spacebar when done.')
    # s.bye()
    con.close()



# Problem 12.19
from sqlite3 import connect
def search2(webdb):
    con = connect(webdb)
    cur = con.cursor()
    while True:
        keyword = input('Enter keyword: ')
        cur.execute("SELECT DISTINCT Keywords.Url, Ranks.rank FROM Keywords, Ranks WHERE Keywords.Url = Ranks.Url AND Keywords.Word = 'Paris' ORDER BY Ranks.rank DESC")
        print('{:15}{:4}'.format('URL', 'RANK'))
        for url, rank in cur:
            print('{:15}{:4}'.format(url, rank))




# Problem 12.23
def partition(intermediate1):
    '''intermediate1 is a list containing [(key, value)] lists;
       returns iterable container with a (key, values) tuple for
       every unique key in intermediate1; values is a list that
       contains all values in intermediate1 associated with key
    '''
    dct = {}                  # dictionary of (key, value) pairs

    # for every (key, value) pair in every list of intermediate1
    for lst in intermediate1: 
        for key, value in lst: 

            if key in dct: # if key already in dictionary dct, add
                dct[key].append(value) # value to list dct[key]
            else:          # if key not in dictionary dct, add
                dct[key] = [value]     # (key, [value]) to dct

    return dct.items()  # return container of (key, values) tuples

class SeqMapReduce(object):
    'a sequential MapReduce implementation'

    def __init__(self, mapper, reducer):
        'functions mapper and reducer are problem specific'
        self.mapper = mapper
        self.reducer = reducer

    def process(self, data):
        'runs MapReduce on data with mapper and reducer functions'
        intermediate1 = [self.mapper(x) for x in data]  # Map
        intermediate2 = partition(intermediate1)
        return [self.reducer(x) for x in intermediate2] # Reduce


from re import findall
def mapper(linums):
    '''linums is a tuple containing a line of a text file and its number
       (i.e. position in the file)

       function returns a list of tuples mapping words in the line to the
       line's number'''
    pattern = '[A-Za-z]+'
    words = findall(pattern, linums[0])
    words = list(set(words))
    return [(words[i].lower(), linums[1]) for i in range(len(words))]

def reducer(keyVal):
    'identity function'
    return keyVal
    
def index(filename):
    'computes and prints the line index of text file filename'
    # obtaine lines, the list of lines of the file
    infile = open(filename)
    lines = infile.readlines()
    infile.close()

    # use lines to construct the list of tuples (lines[i], i)
    # for i = 0, 1, ..., len(lines)-1
    linums = [(lines[i], i) for i in range(len(lines))]


    # use MapReduce to obtain index ind, a list of 2-tuples mapping each word
    # in file filename to a list of lines containg the word
    smp = SeqMapReduce(mapper, reducer)
    ind = smp.process(linums)

    # sort the list (by key of each tuple)
    ind.sort()

    # print the index, with line numbers shown in sorted order
    for record in ind:
        print('{:14}'.format(record[0]), end='')
        record[1].sort()
        for lineNum in record[1]:
            print('{}, '.format(lineNum), end='')
        print()

