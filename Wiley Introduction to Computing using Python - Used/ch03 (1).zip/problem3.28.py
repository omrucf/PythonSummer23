n = eval(input('Enter n: '))
for i in range(n):
    print(i**2)
