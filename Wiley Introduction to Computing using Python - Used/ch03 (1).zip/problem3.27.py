n = eval(input('Enter n: '))
for i in range(4):
    print(n * i)
