n = eval(input('Enter n: '))
n4 = n % 10           # last digit
n3 = (n // 10) % 10   # second to last digit
n2 = (n // 100) % 10  # etc.
n1 = (n // 1000) % 10
print(n1)
print(n2)
print(n3)
print(n4)

