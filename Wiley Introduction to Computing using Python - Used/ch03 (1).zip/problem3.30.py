a = eval(input('Enter the first number: '))
b = eval(input('Enter the second number: '))
c = eval(input('Enter the third number: '))
d = eval(input('Enter the last number: '))
if (a + b + c) / 3 == d:
    print('Equal')

