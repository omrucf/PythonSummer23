lst = eval(input('Enter list: '))
for word in lst:
    if word[0] <= 'M':
        print(word)
