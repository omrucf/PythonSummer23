x = eval(input('Enter x: '))
y = eval(input('Enter y: '))
if x**2 + y**2 <= 8**2:
    print('It is in!')


