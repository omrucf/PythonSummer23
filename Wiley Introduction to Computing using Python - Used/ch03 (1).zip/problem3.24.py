lst = eval(input('Enter a list of words: '))
for word in lst:
    if word != 'secret':
        print(word)
