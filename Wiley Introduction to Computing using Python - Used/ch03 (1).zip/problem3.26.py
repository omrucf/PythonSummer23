lst = eval(input('Enter a list: '))
print('The first list element is', lst[0])
print('The last list element is', lst[-1])
