# Problem 3.33
def reverse_string(s):
    'return input string s with its characters reversed'
    return s[2]+s[1]+s[0]



# Problem 3.34
def pay(wage, hours):
    '''return employee’s pay; overtime (beyond 40 hours)
       is paid at 1.5 times the regular hourly wage'''
    if hours <= 40:
        return hours * wage
    else:
        return 40 * wage + (hours - 40) * 1.5 * wage



# Problem 3.35
def prob(n):
    'return probability of getting n heads in a row'
    return 2**(-n)



# Problem 3.36
def reverse_int(n):
    'return integer obtained by reversing digits of 3-digit number n'
    last = n%10
    middle = (n//10)%10
    first = n//100
    return last*100 + middle*10 + first



# Problem 3.37
import math
def points(x1, y1, x2, y2):
    '''print slope and length of line segment passing
       through points (x1,y1) and (x2,y2)'''
    if x1 != x2:
        slope = (y2-y1)/(x2-x1)
    else:
        slope = 'infinity'
    distance = math.sqrt((x2-x1)**2+(y2-y1)**2)
    print('The slope is ' + str(slope) + ' and the distance is ' + str(distance))



# Problem 3.38
def abbreviation(day):
    'return two-letter abbreviation of day of the week'
    return day[0] + day[1]



# Problem 3.39
def collision(x1, y1, r1, x2, y2, r2):
    '''checks whether two circles with centers (x1,y1) and (x2,y2)
       and radii r1 and r2, respectively, intersect'''
    if (x1-x2)**2 + (y1-y2)**2 <= (r1+r2)**2:
        return True
    else:
        return False



# Problem 3.40
def partition(lst):
    '''prints the names in list lst that start
       with a letter between and including A and M'''
    for name in lst:
        if name[0] < 'N':
            print(name)



# Problem 3.41
def lastF(first, last):
    return last + ', ' + first[0] + '.'



# Problem 3.42
def avg(lst):
    '''lst is a list that contains lists of numbers; the
       function prints, one per line, the average of each list'''
    for grades in lst:
        print(sum(grades)/len(grades))



# Problem 3.43
import math
def hit(xc, yc, rc, xp, yp):
    ''' check whether point (xp, yp) is inside circle
        with center (xc, yc) and radius rc'''
    distance = math.sqrt((xp-xc)**2+(yp-yc)**2)
    if distance > rc:
        return False
    else:
        return True



# Problem 3.44
def distance(seconds):
    '''seconds is the time elapsed between the flash and the sound
       of thunder; function returns the distance to lightning strike
       in kilometers.'''
    return seconds * 340.29 / 1000
