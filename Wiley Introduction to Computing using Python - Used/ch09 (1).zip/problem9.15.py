from tkinter import Tk, Canvas, Frame, Button, SUNKEN, LEFT, RIGHT

# Each time an arrow is pressed, a corresponding line segment is drawn.
# In order to make possible later deletion of the line segment, its id
# must be stored. The deletion of the line segment should also return the
# pen to its original position, at the beginning of the line segment; therefore,
# the move itself must be stored as well

# event handlers
def up():
    'move pen up 10 pixels'
    global y, canvas, segments, moves                  # y is modified
    # create segment and store it id
    segments.append(canvas.create_line(x, y, x, y-10))
    # store move
    moves.append((0,-10))                                                           
    y -= 10

def down():
    'move pen down 10 pixels'
    global y, canvas, segments, moves                   # y is modified
    segments.append(canvas.create_line(x, y, x, y+10))
    moves.append((0,10))
    y += 10

def left():
    'move pen left 10 pixels'
    global x, canvas, segments, moves                   # x is modified
    segments.append(canvas.create_line(x, y, x-10, y))
    moves.append((-10,0))
    x -= 10

def right():
    'move pen right 10 pixels'
    global x, canvas, segments, moves                   # x is modified
    segments.append(canvas.create_line(x, y, x+10, y))
    moves.append((10,0))
    x += 10

def delete():
    'deletes last move'
    global x, y, moves, segments
    # remove line segment from segments, delete it from the canvas and reset
    # the pen position
    last = segments.pop()
    canvas.delete(last)
    move = moves.pop()
    x -= move[0]
    y -= move[1]

def clear():
    'clears all moves'
    global segments, x, y
    for segment in segments:
        canvas.delete(segment)
    x, y = 50, 75

root = Tk()

# canvas with border of size 100 x 150
canvas = Canvas(root, height=100, width=150,
                relief=SUNKEN, borderwidth=3)
canvas.pack(side=LEFT)

# frame to hold the 4 buttons
box = Frame(root)
box.pack(side=RIGHT)

# the 4 button widgets have Frame widget box as their master
button = Button(box, text='up', command=up)
button.grid(row=0, column=0, columnspan=2)
button = Button(box, text='left',command=left)
button.grid(row=1, column=0)
button = Button(box, text='right', command=right)
button.grid(row=1, column=1)
button = Button(box, text='down', command=down)
button.grid(row=2, column=0, columnspan=2)

# new buttons
button = Button(box, text='delete', command=delete)
button.grid(row=1, column=3)
button = Button(box, text='clear', command=clear)
button.grid(row=2, column=3)


# pen position, initially in the middle of the canvas
x, y = 50, 75
segments = []
moves = []

root.mainloop()

