from tkinter import Tk, Canvas, Frame, Button, SUNKEN, LEFT, RIGHT

# NOTE 1: The straighforward solution is to remove the button definitions and
# replace them with statements that bind arrow key press events---described by
# event patterns <Up>, <Down>, <Left>, and <Right>---to the event handling
# functions. The event handling functions must be changed to accept an Event
# input.

# event handlers
def up(event):
    'move pen up 10 pixels'
    global x, y, canvas                  # y is modified
    canvas.create_line(x, y, x, y-10)
    y -= 10

def down(event):
    'move pen down 10 pixels'
    global x, y, canvas                  # y is modified
    canvas.create_line(x, y, x, y+10)
    y += 10

def left(event):
    'move pen left 10 pixels'
    global x, y, canvas                  # x is modified
    canvas.create_line(x, y, x-10, y)
    x -= 10

def right(event):
    'move pen right 10 pixels'
    global x, y, canvas                  # x is modified
    canvas.create_line(x, y, x+10, y)
    x += 10

root = Tk()

# canvas with border of size 100 x 150
canvas = Canvas(root, height=100, width=150,
                relief=SUNKEN, borderwidth=3)

canvas.bind('<Up>', up)
canvas.bind('<Down>', down)
canvas.bind('<Left>', left)
canvas.bind('<Right>', right)

canvas.pack()

# pen position, initially in the middle of the canvas
x, y = 50, 75

root.mainloop()

# NOTE 2: In the above solution, in order for arrow key presses to result
# in lines being drawn in the canvas widget, the canvas widget must be the
# focus of the GUI. To shift the focus from widget to widget in a GUI, press
# the tab key on the keyboard.
#
# An alternative, more appealing solution is to call the bind() method on the
# Tk object root. So instead of using
#
# canvas.bind('<Up>', up)
# canvas.bind('<Down>', down)
# canvas.bind('<Left>', left)
# canvas.bind('<Right>', right)
#
# you would use
#
# root.bind('<Up>', up)
# root.bind('<Down>', down)
# root.bind('<Left>', left)
# root.bind('<Right>', right)
#
# This way, arrow key presses will work regardless of whether the focus is
# on the canvas widget or not.



