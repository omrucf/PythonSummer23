# Problem 9.16
from tkinter import Label, Frame, Entry, Button, END
from tkinter.messagebox import showinfo
class BMI(Frame):
    'Body Mass Index app'
    def __init__(self,parent=None):
        'constructor'
        Frame.__init__(self, parent)
        self.pack()
        BMI.make_widgets(self)

    def make_widgets(self):
        'defines BMI widgets'
        Label(self, text="Enter your height:").grid(row=0,column=0)
        Label(self, text="Enter your weight:").grid(row=1,column=0)
        self.height = Entry(self)
        self.height.grid(row=0,column=1)
        self.weight = Entry(self)
        self.weight.grid(row=1,column=1)
        Button(self, text="Compute BMI", command=self.compute).grid(row=2, column=0, columnspan=2)

    def compute(self):
        'handler for button "Compute BMI"'
        h = eval(self.height.get())
        w = eval(self.weight.get())
        bmi = w*703/h**2
        showinfo(message='Your bmi is {}'.format(bmi))
        self.height.delete(0,END)
        self.weight.delete(0,END)


# Problem 9.17
from tkinter import Label, Frame, Entry, Button, END
class Mortgage(Frame):
    'Mortgage app'
    def __init__(self, parent=None):
        'constructor'
        Frame.__init__(self,parent)
        self.pack()
        Mortgage.make_widgets(self)
        
    def make_widgets(self):
        'defines Mortgage widgets'        
        Label(self, text='Loan Amount: ').grid(row=0, column=0)
        Label(self, text='Interest rate:').grid(row=1, column=0)
        Label(self, text='Loan terms: ').grid(row=2, column=0)
        # mortgage amount entry
        self.amt = Entry(self)
        self.amt.grid(row=0, column=1)
        # mortgage interest rate entry
        self.rate = Entry(self)
        self.rate.grid(row=1, column=1)
        # mortgage term entry
        self.term = Entry(self)
        self.term.grid(row=2, column=1)
        # monthly mortgage computation button 
        Button(self, text='Compute mortgage', command=self.compute).grid(row=3, column=0)
        # monthly mortgage display entry
        self.mort = Entry(self)
        self.mort.grid(row=3, column=1)
        
    def compute(self):
        'event handler for mortgage computation button'
        a = eval(self.amt.get())
        r = eval(self.rate.get())
        t = eval(self.term.get())
        c = r/1200
        m = a*(c*(1+c)**t)/((1+c)**t-1)
        self.mort.delete(0,END)
        self.mort.insert(END, m)



# Problem 9.18
from tkinter import Frame
class GUI(Frame):
    'Click location app'
    def __init__(self, parent=None):
        'constructor'
        Frame.__init__(self, parent, height=480, width=640)
        self.pack()
        self.bind('<Button-1>', self.handler)
    def handler(self, event):
        'handles mouse button clicks by printing its coordinates'
        print('you clicked at ({}, {})'.format(event.x, event.y))

    
# Problem 9.20, 9.21, 9.22
from tkinter import Label, Frame, Entry, Button, END
from random import randrange
class Game(Frame):
    'Number guessing app'
    def __init__(self,parent=None):
        'constructor'
        Frame.__init__(self, parent)
        self.pack()
        Game.make_widgets(self)
        Game.new_game(self)

    def make_widgets(self):
        'defines Game widgets'
        Label(self, text="Enter your guess:").pack()
        self.ent = Entry(self, width=14)
        self.ent.pack()
        # Problem 9.21
        # self.ent.bind('<Return>', self.returnHandler)
        Button(self, text="Enter", command=self.reply).pack()

    # Problem 9.21
    # def returnHandler(self, event):
    #    self.reply()

    def new_game(self):
        'starts new game by choosing secret number'
        self.num = randrange(0,10)

    def reply(self):
        'handles button "Enter" ckicks'
        # compare guess with secret number
        if (eval(self.ent.get()) == self.num):
            # if guess is correct, print message
            showinfo(message="You got it!")

            # Problem 9.22: if guess is correct, print message
            # and start new game
            # showinfo(message="You got it!\nLet's do it again...")
            # Game.new_game(self)

        # erase guess from entry to allow for new guess
        self.ent.delete(0,END)



# Problem 9.23
from tkinter import Label, Frame, Entry, Button, END, LEFT
from random import randrange
class Craps(Frame):
    'Craps app'
    def __init__(self,parent=None):
        'constructor'
        Frame.__init__(self, parent)
        self.pack()
        Craps.make_widgets(self)
        
    def make_widgets(self):
        'defines Craps widgets'
        Label(self, text="Your roll:").pack()
        self.ent = Entry(self,width=26)
        self.ent.pack()
        frame = Frame(self)
        frame.pack()
        Button(frame, text="New game", command=self.new_game).pack(side=LEFT)
        Button(frame, text="Roll for point", command=self.for_point).pack(side=LEFT)

    def new_game(self):
        'handler for "New game" button, starts new game by rolling a pair of dice'
        self.initial = randrange(1, 7) + randrange(1, 7)
        self.ent.delete(0,END)
        if self.initial in [7,11]:
            self.ent.insert(END, "Thow total: {}... you won!".format(self.initial))
        elif self.initial in [2,3,12]:
            self.ent.insert(END, "Thow total: {}... you lost.".format(self.initial))
        else:
            self.ent.insert(END, "Thow total: {}... Throw for point.".format(self.initial))

    def for_point(self):
        'rolls a pair of dice for point'
        tmp = randrange(1, 7) + randrange(1, 7)
        self.ent.delete(0, END)
        if tmp == self.initial:
            self.ent.insert(END, "Thow total: {}... you won!".format(tmp))
        elif tmp == 7:
            self.ent.insert(END, "Thow total: {}... you lost.".format(tmp))
        else:
            self.ent.insert(END, "Thow total: {}... Throw for point.".format(tmp))



# Problem 9.25, 9.26
from tkinter import Label, Frame, Entry, Button, LEFT, RIGHT, END
from random import randrange
class Ed(Frame):
    'Simple arithmetic education app'
    def __init__(self,parent=None):
        'constructor'
        Frame.__init__(self, parent)
        self.pack()
        Ed.make_widgets(self)
        Ed.new_problem(self)

    def make_widgets(self):
        'defines Ed widgets'
        self.ent1 = Entry(self)
        self.ent1.pack(side=LEFT)
        self.ent2 = Entry(self)
        self.ent2.pack(side=LEFT)
        Button(self, text="Enter", command=self.evaluate).pack(side=RIGHT)

    def new_problem(self):
        'creates new arithmetic problem'
        self.ent1.delete(0,END)
        numA = randrange(0,10)
        numB = randrange(0,10)
        oper = randrange(0,2)
        if oper == 0:                    # addition problem
            self.res = numA + numB
            self.ent1.insert(END, numA)
            self.ent1.insert(END, '+')
            self.ent1.insert(END, numB)
        else:                            # subtraction problem               
            if numA < numB:
                numA, numB = numB, numA  # insure result is not negative
            self.res = numA - numB
            self.ent1.insert(END, numA)
            self.ent1.insert(END, '-')
            self.ent1.insert(END, numB)
        # Problem 9.26
        # self.numTries = 0

    def evaluate(self):
        'handles button "Enter" clicks by comparing answer in entry to correct result'
        r = eval(self.ent2.get())
        # Problem 9.26
        # self.numTries += 1
        if r == self.res:
            showinfo(title='Yes!!!', message='You got it!')
            # Problem 9.26
            # showinfo(title='Yes!!!', message='You got it in {} tries!'.format(self.numTries))
            # Ed.new_problem(self)

        self.ent2.delete(0,END)


# Problem 9.28
from tkinter import Tk,Frame,Label,Button
from calendar import monthrange
from tkinter.simpledialog import askstring
class Calendar(Frame):
    'Calendar app'
    def __init__(self, year, month, master=None):
        'constructor for Calendar for given year and month'
        Frame.__init__(self, master)
        self.pack()
        self.year = year
        self.month = month
        self.d = {}
        Calendar.make_widgets(self)

    def make_widgets(self):
        'defines Calendar widgets'
        weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        for i in range(len(weekdays)):
            Label(self, text=weekdays[i]).grid(row=0,column=i)
            (weekday, numDays) = monthrange(self.year,self.month)
            week = 1
            for i in range(1, numDays+1):
                Button(self,text=i,width=2,command=lambda x=i: self.handler(x)).grid(row=week,column=weekday)
                weekday += 1
                if weekday>6:
                    weekday=0
                    week+=1

    def handler(self,i):
        '''handles Calendar button click events by opening an interactive dialog window
           for the day corresponding to the window'''
        if i not in self.d:
            self.d[i] = askstring('Appt','Enter text:')
        else:
            self.d[i] = askstring('Appt','Enter text:',initialvalue=self.d[i])
    
            
