print(f(3))
def f(x):
    return 2*x+1
