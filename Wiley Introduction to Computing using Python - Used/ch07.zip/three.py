import one

def f3():
    one.f4()
