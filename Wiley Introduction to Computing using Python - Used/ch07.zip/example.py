'an example module'
def f():
    'function f'
    print('Executing f()')

def g():
    'function g'
    print('Executing g()')
    
x = 0  # global var

# Solution to Practice Problem 7.6
#if __name__ == '__main__':
#    print('Testing module example:')
#    f()
#    g()
#    print(x)
