# Problem 5.12
def test(n):
    '''prints 'Negative',
'Zero', or 'Positive' depending on value of n'''
    if n > 0:
        print('Positive')
    elif n == 0:
        print('Zero')
    else:
        print('Negative')



# Problem 5.13
# See each problem solution



# Problem 5.14
# iteration loop pattern
def mult3(lst):
    'prints the multiples of 3 in list of numbers lst'
    for num in lst:
        if num%3 == 0:
            print(num)



# Problem 5.15
# counter loop pattern
def vowels(s):
    'prints the indexes of all vowels in string s'
    for i in range(len(s)):
        if s[i] in 'aeiouAEIOU':
            print(i)



# Problem 5.16
# counter loop pattern
def indexes(word, letter):
    'returns a list of indexes at which character letter appears in word'
    res = []
    for i in range(len(word)):
        if word[i] == letter:
            res.append(i)
    return res



# Problem 5.17
# counter loop pattern
def doubles(l):
    '''prints integers in list l that are exactly twice
       the previous integer in the list'''
    for i in range(1, len(l)):
        if l[i] == 2*l[i-1]:
            print(l[i])



# Problem 5.18
# iteration and accumulator loop patterns
def four_letter(lst):
    'returns list of 4-letter words in list of strings lst'
    res = []
    for word in lst:
        if len(word) == 4:
            res.append(word)
    return res



# Problem 5.19
# iteration and nested loop patterns
def inBoth(lst1, lst2):
    'checks whether there is an item that is common to lists lst1 and lst2'
    for item in lst1:
        if item in lst2:
            return True
    return False



# Problem 5.20
# iteration loop pattern
def intersect(lst1, lst2):
    '''returns the list of items common to lists lst1 and lst2,
       neither containing duplicate items'''
    res = []
    for item in lst1:
        if item in lst2:
            res.append(item)
    return res



# Problem 5.21
# counter and nested loop patterns
def pair(lst1, lst2, x):
    '''prints the pairs of integers, one from list lst1 and the other
       from list lst2, that add up to n'''
    for i in lst1:
        for j in lst2:
            if i + j == x:
                print(i, j)



# Problem 5.22
# counter and nested loop patterns
def pairSum(lst, x):
    'prints the indexes of all pairs of values in list lst that sum up to n'
    for i in range(len(lst)-1):        # left index in pair
        for j in range(i+1,(len(lst))):  # right index in pair
            if lst[i]+lst[j] == x:
                print(i,j)


# Problem 5.23
def pay(rate, hours):
    '''returns wage based on rate and hours

       Any hours beyond 40 but less than or equal 60 are paid at
       1.5 times the regular hourly wage. Any hours beyond 60 are
       paid at 2 times the regular hourly wage'''
    if hours <= 40:
        return hours*rate
    elif hours <= 60:
        return 40*rate+(hours-40)*1.5*rate
    else:
        return 40*rate+20*1.5*rate+(hours-60)*2*rate



# Problem 5.24
def case(s):
    '''returns 'capitalized', 'not capitalized', or 'unknown'
       depending on whether the string starts with an uppercase
       letter, lowercase letter, or other'''
    if s[0].islower():
        return 'not capitalized'
    elif s[0].isupper():
        return 'capitalized'
    else:
        return 'unknown'



# Problem 5.25
def leap(year):
    'checks whether year is a leap year'
    if year%4 != 0:
        return False
    elif year%100 != 0:
        return True
    elif year%400 != 0:
        return False
    else:
        return True



# Problem 5.26
def rps(play1, play2):
    '''takes choices ('R', 'P', or 'S') of player 1 and 2,
       and returns -1 if player 1 wins, 1 if player 2 wins,
       or 0 if there is a tie'''
    if play1 == play2:
        return 0
    if (play1 == 'P' and play2 == 'R') or (play1 == 'R' and play2 == 'S') or (play1 == 'S' and play2 == 'P'):
        return -1
    else:
        return 1



# Problem 5.27
def letter2number(lgrade):
    'returns the number grade corresponding to the letter grade lgrade'
    # handle + and - signs first
    if len(lgrade) == 1:
        add = 0.0
    elif lgrade[1] == '-':
        add = -0.3
    elif lgrade[1] == '+':
        add = 0.3

    if lgrade[0] == 'A':
        return 4 + add
    elif lgrade[0] == 'B':
        return 3 + add
    elif lgrade[0] == 'C':
        return 2 + add
    elif lgrade[0] == 'D':
        return 1 + add
    else:               # lgrade[0] must be 'F'
        return 0



# Problem 5.28
def geometric(lst):
    'checks whether the integers in list lst form a geometric sequence'
    if len(lst) <= 1:
        return True
    
    ratio = lst[1]/lst[0]
    for i in range(1, len(lst)-1):
        if lst[i+1]/lst[i] != ratio:
            return False
    return True



# Problem 5.29
def lastfirst(lst):
    '''lst is a list of strings of the format <LastName, FirstName>;
       function returns a list consisting two lists: a list of all the
       first names and a list of all the last names'''
    first = []
    last = []
    for s in lst:
        pair = s.split(', ')
        last.append(pair[0])
        first.append(pair[1])
    return [first, last]



# Problem 5.30
def many(filename):
    'prints the number of words of length 1, 2, 3, and 4 in file filename'
    # get file content
    infile = open(filename)
    content = infile.read()
    infile.close()

    # replace punctuation with blank spaces and obtain list of words
    table = str.maketrans('.,;!?:\n', 7*' ' )
    words = content.translate(table).split()

    # a list of 4 word counters
    counters = [0,0,0,0] 

    #  for every word of length 1 to 4, increment appropriate counter
    for word in words:
        if len(word) <= 4:
            counters[len(word)-1] += 1

    # output counts
    for i in range(4):
        print('Words of length {}: {}'.format(i+1, counters[i]))



# Problem 5.31
def subsetSum(lst, target):
    'checks whether there are 3 numbers in list lst that add up to target'
    for i in range(len(lst)-2):
        for j in range(i+1, len(lst)-1):
            for k in range(j+1, len(lst)):
                if lst[i] + lst[j] + lst[k] == target:
                    return True
    return False
                


# Problem 5.32
def fib(n):
    'returns the nth Fibonacci number'
    prev = 1       # Fibonacci number 0
    current = 1    # Fibonacci number 1
    
    for i in range(2, n+1): # compute ith Fibonacci number (current)
        prev, current = current, prev+current
    return current



# Problem 5.33
def mystery(x):
    '''returns the number of times necessary te halve n
       (using integer division) before reaching 1'''
    i = 0
    while x > 1:
        x //= 2
        i += 1
    return i



# Problem 5.34   
def statement(lst):
    '''returns a list of two numbers; the first is the sum of the
       positive numbers (deposits) in list lst, and the second is
       the sum of the negative numbers (withdrawals)'''
    deposit = 0
    withdrawal = 0
    for amount in lst:
        if amount < 0:
            withdrawal += amount
        else:
            deposit += amount
    return [withdrawal, deposit]



# Problem 5.35  
def pixels(picture):
    '''picture is a two-dimensional list of nonnegative integers;
       function returns the number of entries that are positive'''
    res = 0
    for row in picture:
        for entry in row:
            if entry > 0:
                res += 1
    return res



# Problem 5.36
import math
def prime(n):
    'checks whether positive integer n is a prime'
    if n == 2:
        return True
    if n < 2 or n % 2 == 0:
        return False
    upper = math.ceil(math.sqrt(n))
    i = 3
    while i <= upper:
        if n%i == 0:
            return False
        i += 2
    return True


# Problem 5.37
def mssl(lst):
    'returns the sum of the maximum sum sublist of list lst'
    best = 0
    for i in range(len(lst)):
        for j in range(i+1, len(lst)+1):
            total = 0
            for k in range(i, j):
                total += lst[k]
            if total > best:
                best = total
    return best



# Problem 5.38
def collatz(n):
    'prints the Collatz sequence starting at n'
    while n != 1:
        print(n)
        if n%2 == 0:
            n //= 2
        else:
            n = 3*n+1
    print(n)



# Problem 5.39
def exclamation(word):
    'returns exclamation version of word'
    res = ''
    for c in word:
        if c in 'aeiou':
            res+=3*c
        else:
            res+=c
    return res+'!'



# Problem 5.40  
import math
def approxPi(error):
    'returns approaximation of Pi within error'
    prev = 4
    current = 4 - 4/3
    sign = 1
    i = 5
    while abs(current-prev) > error:
        prev, current = current, current + sign*4/i
        i += 2
        sign *= -1
    return current



# Problem 5.41
def poly(a, x):
    '''a is a list of coefficients a0, a1, a2, a3, . . . , an of
       a polynomial p(x) = a0 + a1*x + a2*x**2 + ... + an*x**n;
       function computes and returns p(x)'''
    res = 0
    for i in range(len(a)):
        res += a[i]*x**i
    return res




# Problem 5.42
def primeFac(n):
    'returns a list containing all the numbers in the prime factorization of n'
    res = []
    prime = 2
    while n > 1:
        if n%prime == 0:
            res.append(prime)
            n //= prime
        else:
            prime += 1
    return res



# Problem 5.43
def evenrow(table):
    '''checks whether each row of the two-dimensional list table
       sums up to an even number'''
    for row in table:
        if sum(row)%2 != 0:
            return False
    return True



# Problem 5.44
def encrypt(key, number):
    '''key is a string representing a permutation of digits 0 to 9;
       function returns the encryption of digit string number using key
       as the substitution cipher'''
    res = ''
    for c in number:
        res = res + key[int(c)]
    return res



# Problem 5.45
def avgavg(lst):
    '''lst is a list whose items are lists of three numbers;
       function prints a list containing the average of each
       list of three numbers and the average of all averages'''
    avgList = []
    for sublist in lst:
        avgList.append(sum(sublist)/3)
    print(avgList)
    print(sum(avgList)/len(avgList))



# Problem 5.46
def inversions(s):
    'returns the number of inversions in sequence s'
    res = 0
    for i in range(len(s)-1):
        for j in range(i+1, len(s)):
            if s[i] > s[j]:
                res += 1
    return res



# Problem 5.47
def d2x(n, b):
    'returns a string of digits that represent the base-b representation of n'
    res = ''
    while n > 0:
        res = str(n%b) + res
        n //= b
    return res



# Problem 5.48
def sublist(lst1, lst2):
    'checks whether list lst1 is a sublist of list lst2'
    index1 = 0                # lst1 index
    index2 = 0                # lst2 index

    # go through indexes of lst1
    while index1 < len(lst1):
        
        # search for item in lst2 matching item in lst1 at index index1
        while index2 < len(lst2) and lst1[index1] != lst2[index2]:
            index2+=1

        # if we run out of items in lst2, lst1 is not a sublist of lst2
        if index2 == len(lst2):
            return False
        index1 += 1

    # every item in lst1 has been matched to an item in lst2, from left to right
    return True



# Problem 5.49
def heron(n, error):
    prev = 1.0         # first guess
    curr = (n+1.0)/2   # second guess
    while (abs(curr - prev) > error):
        prev, curr = curr, (curr + n/curr)/2
    return curr
