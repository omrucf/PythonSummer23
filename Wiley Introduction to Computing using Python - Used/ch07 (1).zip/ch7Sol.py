# Problem 7.16
def index(filename, words):
    '''prints a mapping of words from list words to all the line
       numbers of lines in which the words appear in file filename'''
    try:
        infile = open(filename)
    except IOError:
        print('File {} not found.'.format(filename))
        return

    # initialize dictionary mapping words to lists of line numbers
    d = {}
    for word in words:
        d[word] = []

    lineNum = 0                  # line number

    while True:
        line = infile.readline() # read line and increment line number
        lineNum += 1
        if line == '':           # end of file
            break
        for c in '!-_:;\'",.?':  # remove punctuation
            line = line.replace(c, ' ')
        wordList = line.split()  # obtain list of words

        # for every word in words, if word in line, update dictionary
        for word in words:
            if word in wordList:
                d[word].append(lineNum)
    infile.close()

    # output line index
    for word in d:
        print('{:10}{}'.format(word, d[word][0]), end='')
        for index in range(1, len(d[word])):
            print(', {}'.format(d[word][index]), end='')
        print()



# Problem 7.17
from random import randint
def game(n):
    'an app to teach simple arithmetic'
    count = 0
    for i in range(n):
        x, y = randint(0,9), randint(0,9)
        print(x, ' + ', y, ' = ')

        # repeatedly request user input until it is in a correct format
        while True:
            try:
                ans = int(input("Enter answer: " ))
                break
            except ValueError:
                print('Please write your answer using digits 0 though 9. Try again!')

        if ans == x+y:
            print("Correct.")
            count += 1
        else:
            print("Incorrect.")
    print("You got", count, "correct answers out of", n)



# Problem 7.19
def inValues():
    '''interactive function that requests non-zero numbers from the user;
       when the user enters 0, the sum of the numbers input is printed.

       The function terminates when the user enters two invalid inputs
       in a row.'''
    total = 0         # sum of the inputs
    errors = 0        # error count             
    while True:
        try:
            x = eval(input('Please enter a number: '))
            if x == 0:
                break
            total += x
            errors = 0
        except:       # invalid input handler
            if errors > 0:
                print('Two errors in a row. Quitting ...')
                return
            else:
                errors = 1
                print('Error. Please re-enter the value.')
    return total



# Problem 7.20
def inValues2():
    '''interactive function that requests non-zero numbers from the user;
       when the user enters 0, the sum of the numbers input is printed.

       The function terminates when the user enters two invalid inputs.'''
    total = 0         # sum of the inputs
    errors = 0        # error count             
    while True:
        try:
            x = eval(input('Please enter a number: '))
            if x == 0:
                break
            total += x
        except:       # invalid input handler
            if errors > 0:
                print('Second error. Quitting ...')
                return
            else:
                errors = 1
                print('Error. Please re-enter the value.')
    return total




# Problem 7.21
def safe_input():
    'wrapper function for built-in function input() that catches exceptions'
    try:
        return input()
    except:
        pass
