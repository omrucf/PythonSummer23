# Exercise 10.12
# The recursive call is made first and the print(n) statement is executed
# after the recursive call is done. This means that n is printed after
# "Blastoff!" and all the other numbers have been printed. Therefore, the
# numbers are printed in increasing order rather than decreasing.
def countdown2(n):
    'counts down to 0'
    if n <= 0:               # base case
        print('Blastoff!!!')
    else:                    # n > 0: recursive step 
        countdown2(n-1)           # count down from n-1
        print(n)                 # print n first and then



# Exercise 10.14
def countdown3(n):
    'counts down to 0'
    if n <= 0:               # base case
        print('Blastoff!!!')
    else:                    # n > 0: recursive step
        print(n)                 # print n first and then
        if n == 3:
            print('    BOOM!!!\n    Scared you...')
        countdown3(n-1)           # count down from n-1



# Exercise 10.16
def combinations(n,k):
    'returns the number of ways of choosing k items out of n'
    if k==0:
        return 1
    elif n < k:
        return 0
    else:
        return combinations(n-1,k-1)+combinations(n-1,k)



# Exercise 10.17
# The number of class made for n = 10, 20, and 30 is 176, 10,946, and
# 2,692,536, respectively, as shown below:
# >>> counter = 0
# >>> rfib(10)
# 89
# >>> counter
# 176
# >>> counter = 0
# >>> rfib(20)
# 10946
# >>> counter
# 21890
# >>> counter = 0
# >>> rfib(30)
# 1346269
# >>> counter
# 2692536
#
counter = 0
def rfib(n):
    '''returns n-th Fibonacci number; also sets global variable counter
       to the total number of recursive calls made.'''
    global counter
    if n < 2:                     # base case
        return 1
    counter += 2
    return rfib(n-1) + rfib(n-2)  # recursive step


# Problem 10.18
def silly(n):
    'prints n stars followed by n exclamation marks'
    if n > 0:
        print('*',end='')
        silly(n-1)
        print('!',end='')



# Problem 10.19
def numOnes(n):
    'returns number of 1s in the binary representation of non-negative integer n'
    if n == 0:
        return 0
    if n%2 == 0:
        return numOnes(n//2)
    else:
        return numOnes(n//2)+1



# Problem 10.20
def rgcd(a, b):
    'returns the greatest common denominator of non-negative integers a and b'
    if b == 0:
        return a
    return rgcd(b, a%b)



# Problem 10.21
def rem(lst):
    'returns copy of list lst in which one copy of every duplicate item is removed'
    # sort list first so duplicates are adjacent
    lst.sort()
    new=[]

    # an item of lst is added to list new only if it is equal to
    # the item preceding it
    for i in range(1, len(lst)):
        if lst[i] == lst[i-1]:
            new.append(lst[i])
    return new



# Problem 10.22
def address(lst):
    'returns central location'
    # sort list so the "median" is in the middle
    lst.sort()
    # return median, if lst is of odd size, or the lower of the two
    # middle items, otherwise
    return lst[(len(lst)-1)//2]


# Problem 10.23
def f(i, n):
    'prints a recursive pattern'
    if (n > 0):
        f(i, n//2)
        print(i * ' ' + n * '*')
        f(i + n//2, n//2)


# Problem 10.24
def base(n, b):
    'returns base-b (1 < b < 10) representation of non-negative integer n'
    if n < b:
        print(n, end=" ")
    else:
        base(n//b, b)
        print(n%b, end=" ")


# Problem 10.25
def permutations(lst):
    'returns list of all permutations (represented as lists) of list lst'
    # base case
    if len(lst) < 2:
        return [lst]

    # induction step, start by obtaining recursively
    # all the permutations of lst[1:]
    perms = permutations(lst[1:])

    # for every permutation of lst[1:], obtain permutations of lst by
    # inserting lst[0] at every possible location
    res = []
    for perm in perms:
        for i in range(len(lst)):
             res.append(perm[:i] + [lst[0]] + perm[i:])
    return res



# Problem 10.26
def strPermutations(s):
    'returns list of all permutations of characters of string s'
    if len(s) < 2:
        return [s]
    perms = strPermutations(s[1:])
    res = []
    for perm in perms:
        for i in range(len(s)):
             res.append(perm[:i]+s[0]+perm[i:])
    return res

def anagrams(filename, word):
    'prints anagrams of word based on words in file filename'
    infile= open(filename)
    wordList = infile.read().split()
    infile.close()
    perms = strPermutations(word)
    for perm in perms:
        if perm in wordList:
            print(perm)



# Problem 10.27
def pairs1(lst, target):
    '''Checks whether there are two integers in list lst of integers that
       add up to target.

       The search is done by exhaustively computing the sum for every pair
       of integers in list lst.'''
    for i in range(len(lst)-1):
        for j in range(i+1, len(lst)):
            if lst[i] + lst[j] == target:
                return True
    return False
               

def pairs2(lst, target):
    '''Checks whether there are two integers in list lst of integers that
       add up to target.

       After sorting the list, the search for the pair of integers is done as
       follows. The sum of the first and last integers is computed. If the sum
       is smaller than target, then the first integer cannot be in the solution
       pair and the search continues with the second and last integers. If the sum
       is greater than target, then the last integer cannot be in the solution
       pair and the search continues with the first and next-to-last integers. '''
    lst.sort()
    i = 0            # index of smaller integer in pair
    j = len(lst)-1   # index of larger integer in pair
    while i < j:
        s = lst[i] + lst[j] 
        if s == target:
            return True
        elif s < target: # sum is too small, so consider next smallest integer 
            i+=1
        else:            # sum is too large, so consider next largest integer
            j-=1
    print('no pair adds up to',target)


# To run timingAnalysis(), we implement function buildInput() that constructs
# a list of randomly chosen integers in the range [0, 4n) and a random integer
# target in the range [0, 8n-1). Because our timingAnalysis framework lets us
# test functions with one input only, we write wrapper functions that take
# the generated pair (lst, target) as as tuple and call the appropriate function.

def wrapPairs1(tpl):
    return pairs1(tpl[0], tpl[1])

def wrapPairs2(tpl):
    return pairs2(tpl[0], tpl[1])

import random
def buildInput(n):
    '''returns a tuple containing a random sample of n integers in
       range [0, 4n) and a random integer in the range [0, 8n)'''
    lst = random.sample(range(4*n), n)  
    target = random.choice(range(8*n))
    return (lst, target)

import time
def timing(func, n):
    'runs func on input returned by buildInput'
    funcInput = buildInput(n)  # obtain input for func 

    start = time.time()        # take start time
    func(funcInput)            # run func on funcInput
    end = time.time()          # take end time

    return end - start         # return execution time

def timingAnalysis(func, start, stop, inc, runs):
    '''prints average run-times of function func on inputs of
       size start, start+inc, start+2*inc, ..., up to stop'''

    for n in range(start, stop, inc):  # for every input size n
        acc=0.0                        # initialize accumulator

        for i in range(runs):       # repeat runs times:
            acc += timing(func, n)      # run func on input of size n
                                        # and accumulate run-times
        # print average run times for input size n
        formatStr = 'Run-time of {}({}) is {:.7f} seconds.'
        print(formatStr.format(func.__name__,n,acc/runs))

# Results:
# >>> timingAnalysis(wrapPairs1, 10000, 50000, 10000, 50)
# Run-time of wrapPairs1(10000) is 0.0617672 seconds.
# Run-time of wrapPairs1(20000) is 0.0764420 seconds.
# Run-time of wrapPairs1(30000) is 0.3318517 seconds.
# Run-time of wrapPairs1(40000) is 0.4270773 seconds.
# >>> timingAnalysis(wrapPairs2, 10000, 50000, 10000, 50)
# Run-time of wrapPairs2(10000) is 0.0084601 seconds.
# Run-time of wrapPairs2(20000) is 0.0181129 seconds.
# Run-time of wrapPairs2(30000) is 0.0342777 seconds.
# Run-time of wrapPairs2(40000) is 0.0503310 seconds.



# Problem 10.28
def crawl(filename):
    '''crawls through a set of “linked” files. Every file visited by the
       crawler contains zero or more links, one per line, to other files
       and nothing else. A link to a file is just the name of the file.

       For example, the content of file file0.txt could be:

       file1.txt
       file2.txt
    '''
    print('Visiting {}'.format(filename))
    infile = open(filename)
    links = infile.readlines()
    infile.close()
    for link in links:
        crawl(link[:-1])



# Problem 10.29
def pascalLine(n):
    '''returns a list containing the sequence of numbers appearing in the
       nth line of Pascal’s triangle'''
    if n == 0:       # base case
        return [1]

    # induction step: start by generating line n-1
    prev = pascalLine(n-1)

    # use line n-1 to generate line n
    res = [1]
    for index in range(len(prev)-1):
        res.append(prev[index]+prev[index+1])
    res.append(1)
    return res



# Problem 10.30
from os import listdir
from os.path import join
def traverse(path, depth):
    '''Prints the relative pathname of every file and subfolder contained,
       directly or indirectly, in the folder described by pathname path.
       
       Integer depth specifies the indentation to be used when printing.'''
    for item in listdir(path):
        itemPath = join(path, item)
        print(' '*2*depth+itemPath)
        try:    # recursively traverse a subfolder
            traverse(itemPath, depth+1)
        except: # base case: exception means that item is a file
              pass



# Problem 10.32
def levy(n):
    'returns turtle instructions to draw nth Levy curve”'
    if n == 0:
        return 'F'
    tmp = levy(n-1)
    return 'L' + tmp + 'R' + tmp + 'L'

from turtle import Screen, Turtle
from math import sqrt
def drawLevy(n):
    'draws nth Levy curve using instructions obtained from function levy()'    
    directions = levy(n)
    s = Screen()
    t = Turtle()
    #s.bgcolor('black')
    #t.pencolor('red')
    t.pensize(2)
    for move in directions:
        if move == 'F':
            t.fd(200/sqrt(2)**n)
        if move == 'L':
            t.lt(45)
        if move == 'R':
            t.rt(90)
    s.bye()


# Problem 10.33
def coins(n):
    '''returns True if, starting with n coins, there is a way
       in the simple coin game to end up with 8 coins, False otherwise'''
    if n < 8:
        return False
    if n == 8:
        return True
    if n%10 == 0 and coins(n-9):
        return True
    if n%2 == 0 and coins(n//2+1):
        return True
    if n%3 == 0 and coins(n-7):
        return True
    if n%4 == 0 and coins(n-6):
        return True
    return False


# Problem 10.34
def recDup(lst):
    'returns a copy of list lst in which every item has been duplicated'
    if len(lst) == 0:
        return []
    return recDup(lst[:-1]) + [lst[-1]]*2


# Problem 10.35
def recReverse(lst):
    'returns a reversed copy of list lst'
    if len(lst) == 0:
        return []
    return [lst[-1]] + recReverse(lst[:-1])


# Problem 10.36
def recSplit(lst, i):
    '''splits a copy of list lst so that the second part contains the
       last i items of lst; a list containing the two slices is returned'''
    if i == 0:
        return [lst, []]
    res = recSplit(lst[:-1], i-1)
    return [res[0], res[1]+[lst[-1]]]

# Problem 10.37
def jump(t, x, y):
    'makes turtle t jump to coordinates (x,y)'
    t.penup()
    t.goto(x,y)
    t.pendown()

def square(t, x, y, l):
    'has turtle t draw a square with side length l centered at (x, y)'
    jump(t, x-l/2, y-l/2)
    t.setheading(0)
    t.goto(x+l/2, y-l/2)
    t.left(90)
    t.goto(x+l/2, y+l/2)
    t.left(90)
    t.goto(x-l/2, y+l/2)
    t.left(90)
    t.goto(x-l/2, y-l/2)

def squares(t, x, y, l, n):
    'draws nth pattern of squares'
    # base case, when n = 0: do nothing
    if n > 0:           # induction step
        # draw central square first
        square(t,x,y,l)

        # recursively draw the n-1st patterns centered at
        # the 4 corners of the central square
        squares(t,x+l/2,y+l/2,l/2.2,n-1)
        squares(t,x-l/2,y+l/2,l/2.2,n-1)
        squares(t,x+l/2,y-l/2,l/2.2,n-1)
        squares(t,x-l/2,y-l/2,l/2.2,n-1)
    
