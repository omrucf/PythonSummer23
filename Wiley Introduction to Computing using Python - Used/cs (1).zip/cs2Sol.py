# Problem CS.2
>>> import turtle
>>> s = turtle.Screen()
>>> t = turtle.Turtle()
>>> t.forward(100)
>>> t.left(90)
>>> t.forward(100)
>>> t.left(90)
>>> t.forward(100)
>>> t.left(90)
>>> t.forward(100)
>>> s.bye()



# Problem CS.3
>>> s = turtle.Screen()
>>> t = turtle.Turtle()
>>> t.left(45)
>>> t.forward(100)
>>> t.left(90)
>>> t.forward(100)
>>> t.left(90)
>>> t.forward(100)
>>> t.left(90)
>>> t.forward(100)
>>> s.bye()


# Problem CS.4
The interior angles of a pentagon are 108 degrees, therefore the turtle has
to turn 180 - 108 = 72 degrees at every pentagon node.
>>> s = turtle.Screen()
>>> t = turtle.Turtle()
>>> t.forward(100)
>>> t.left(72)
>>> t.forward(100)
>>> t.left(72)
>>> t.forward(100)
>>> t.left(72)
>>> t.forward(100)
>>> t.left(72)
>>> t.forward(100)
>>> s.bye()
In general, the interior angles of a p-gon are (p-2)*180/p degrees. That means
120 degrees for a hexagon, and so the turtle must turn 60 degrees at every
hexagon node.
>>> s = turtle.Screen()
>>> t = turtle.Turtle()
>>> t.forward(100)
>>> t.left(60)
>>> t.forward(100)
>>> t.left(60)
>>> t.forward(100)
>>> t.left(60)
>>> t.forward(100)
>>> t.left(60)
>>> t.forward(100)
>>> t.left(60)
>>> t.forward(100)
>>> s.bye()
The heptagon and octogon can be drawn similarly.


# Problem CS.5
>>> import turtle
>>> s = turtle.Screen()
>>> t = turtle.Turtle()
>>> t.circle(radius=100)
>>> t.penup()
>>> t.goto(-50, -87)
>>> t.pendown()
>>> t.circle(radius=100)
>>> t.penup()
>>> t.goto(50, -87)
>>> t.pendown()
>>> t.circle(radius=100)
>>> s.bye()



# Problem CS.6
>>> import turtle
>>> s = turtle.Screen()
>>> t = turtle.Turtle()
>>> t.circle(radius=10)
>>> t.penup()
>>> t.goto(0, -40)
>>> t.pendown()
>>> t.circle(radius=50)
>>> t.penup()
>>> t.goto(0, -65)
>>> t.pendown()
>>> t.circle(radius=75)
>>> t.penup()
>>> t.goto(0, -90)
>>> t.pendown()
>>> t.circle(radius=100)
>>> s.bye()


# Problem CS.7
# code that follows the code from Practice problem 2.11:
>>> t2 = turtle.Turtle()
>>> t2 = turtle.Turtle(shape='turtle')
>>> t2.penup()
>>> t2.goto(-100, -75)
>>> t3 = turtle.Turtle(shape='turtle')
>>> t3.penup()
>>> t3.setheading(115)
>>> t3.goto(200, -55)
>>> s.bye()
                       

# Problem CS.8
>>> import turtle
>>> s = turtle.Screen()
>>> t = turtle.Turtle()
>>> t.circle(1)
>>> t.penup()
>>> t.goto(0, -108)
>>> t.pendown()
>>> t.circle(109)
>>> s.bye()


# Problem CS.9
# pentagram
>>> import turtle
>>> s = turtle.Screen()
>>> t = turtle.Turtle()
>>> t.forward(100)
>>> t.left(144)
>>> t.forward(100)
>>> t.left(144)
>>> t.forward(100)
>>> t.left(144)
>>> t.forward(100)
>>> t.left(144)
>>> t.forward(100)
>>> s.bye()
# star of David
>>> s = turtle.Screen()
>>> t = turtle.Turtle()
>>> t.forward(100)
>>> t.left(120)
>>> t.forward(100)
>>> t.left(120)
>>> t.forward(100)
>>> t.penup()
>>> t.goto(100, 58)
>>> t.pendown()
>>> t.forward(100)
>>> t.right(120)
>>> t.forward(100)
>>> t.right(120)
>>> t.forward(100)
