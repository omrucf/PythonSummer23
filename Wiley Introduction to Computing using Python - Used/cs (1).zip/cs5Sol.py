# Problem CS.28
def negative(original):
    'returns copy of image photo'
    # create a new image of the same mode and size as original
    res = PIL.Image.new(original.mode, original.size)
    # width = original.size[0], height = original.size[1]
    width, height = original.size

    # nested loop pattern to access individual pixels
    for i in range(0, width):
        for j in range(0, height):
            # set pix to color of pixel
            # at location (i,j) of original
            pix = original.getpixel((i,j))
            neg = (255-pix[0], 255-pix[1], 255-pix[2])
            # set pixel at location (i,j) of res to pix
            res.putpixel((i,j), neg)
    return res



# Problem CS.31
def blackAndWhite(original):
    'returns copy of image photo'
    # create a new image of the same mode and size as original
    res = PIL.Image.new(original.mode, original.size)
    # width = original.size[0], height = original.size[1]
    width, height = original.size

    # nested loop pattern to access individual pixels
    for i in range(0, width):
        for j in range(0, height):
            # set pix to color of pixel
            # at location (i,j) of original
            pix = original.getpixel((i,j))
            # avg = (pix[0]+pix[1]+pix[2])//3
            avg = int(0.21*pix[0]+0.72*pix[1]+0.07*pix[2])
            # set pixel at location (i,j) of res to pix
            res.putpixel((i,j), (avg,avg,avg))
    return res




# Problem CS.32
def smooth2(original):
    'returns blurred copy of original'
    res = PIL.Image.new(original.mode, original.size)
    width, height = original.size
    for i in range(0, width):
        for j in range(0, height):
            pixel = original.getpixel((i,j))
            red,green,blue = 4*pixel[0],4*pixel[1],4*pixel[2]
            numPixels = 4
            for c in range(max(0,i-1),min(width,i+2)):
                for r in range(max(0,j-1),min(height,j+2)):
                    numPixels +=1
                    pixel = original.getpixel((c,r))
                    red,green,blue = red+pixel[0],green+pixel[1],blue+pixel[2]
            red,green,blue = red//numPixels,green//numPixels,blue//numPixels
            res.putpixel((i,j), (red,green,blue))
    return res




# Problem CS.33
def sharpen(original):
    'returns sharp copy of original'
    res = PIL.Image.new(original.mode, original.size)
    width = original.size[0]
    height = original.size[1]
    for i in range(0, width):
        for j in range(0, height):
            pixel = original.getpixel((i,j))
            red,green,blue = 34*pixel[0],34*pixel[1],34*pixel[2]
            numPixels = 34
            for r in range(max(0,i-1),min(width,i+2)):
                for c in range(max(0,j-1),min(height,j+2)):
                    numPixels -=2
                    pixel = original.getpixel((r,c))
                    red,green,blue = red-2*pixel[0],green-2*pixel[1],blue-2*pixel[2]
            red,green,blue = red//numPixels,green//numPixels,blue//numPixels
            res.putpixel((i,j), (red,green,blue))
    return res


# Problem CS.34
def blur(original):
    'returns blurred copy of original'
    res = PIL.Image.new(original.mode, original.size)
    width = original.size[0]
    height = original.size[1]
    for i in range(0, width):
        for j in range(0, height):
            red,green,blue = 0,0,0
            numPixels = 0
            for c in range(max(0,i-2),min(width,i+3)):
                if j - 2 >= 0:
                    pixel = original.getpixel((c, j-2))
                    red,green,blue = red+pixel[0],green+pixel[1],blue+pixel[2]
                    numPixels += 1
                if j + 2 < height: 
                    pixel = original.getpixel((c, j+2))
                    red,green,blue = red+pixel[0],green+pixel[1],blue+pixel[2]
                    numPixels += 1
            for r in range(max(0,j-1),min(height,j+2)):
                if i - 2 >= 0:
                    pixel = original.getpixel((i-2,r))
                    red,green,blue = red+pixel[0],green+pixel[1],blue+pixel[2]
                    numPixels += 1
                if i + 2 < width:
                    pixel = original.getpixel((i+2,r))
                    red,green,blue = red+pixel[0],green+pixel[1],blue+pixel[2]
                    numPixels += 1
            red,green,blue = red//numPixels,green//numPixels,blue//numPixels
            res.putpixel((i,j), (red,green,blue))
    return res

