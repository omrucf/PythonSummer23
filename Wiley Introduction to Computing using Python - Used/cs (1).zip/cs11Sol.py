

# Problem CS.63
from urllib.parse import urljoin
from html.parser import HTMLParser
class Collector2(HTMLParser):
    'collects hyperlink URLs into a list'

    def __init__(self, url):
        'initializes parser, the url, and a list'
        HTMLParser.__init__(self)
        self.url = url
        self.links = []
        
    def handle_starttag(self, tag, attrs):
        'collects hyperlink URLs in their absolute format'
        if tag == 'a':
            for attr in attrs:
                if attr[0] == 'href':
                    # construct absolute URL
                    absolute = urljoin(self.url, attr[1])
                    if absolute[:4] == 'http': # collect HTTP URLs
                        self.links.append(absolute)

    def getLinks(self):
        'returns hyperlinks URLs in their absolute format'
        return self.links



from urllib.request import urlopen
spam_dict = {}
def spam(url, n):
    '''recursively, and up to recursive depth n, collects email addresse
       in WWW HTML documents starting at page wuth URL url'''
    content = urlopen(url).read().decode()
    mail_list = emails(content)
    global spam_dict
    for email in mail_list:
      if email not in spam_dict:
        spam_dict[email] = email
    if n == 0:
        return
    collector = Collector2(url)
    collector.feed(content)
    urls = collector.getLinks()          # get list of links
    for link in urls:
        try:
            spam(link, n-1)
        except:
            pass



# Problem CS.64
from urllib.parse import urljoin
from html.parser import HTMLParser
class Collector(HTMLParser):
    'collects hyperlink URLs into a list'

    def __init__(self, url):
        'initializes parser, the url, and a list'
        HTMLParser.__init__(self)
        self.url = url
        self.links = []

        # Solution to Practice Problem 11.3        
        self.text = ''
        
    def handle_starttag(self, tag, attrs):
        'collects hyperlink URLs in their absolute format'
        if tag == 'a':
            for attr in attrs:
                if attr[0] == 'href':
                    # construct absolute URL
                    absolute = urljoin(self.url, attr[1])
                    if absolute[:4] == 'http': # collect HTTP URLs
                        self.links.append(absolute)
                        
    # Solution to Practice Problem 11.3        
    def handle_data(self, data):
        'collects and concatenates text data'
        self.text += data

    def getLinks(self):
        'returns hyperlinks URLs in their absolute format'
        return self.links

    # Solution to Practice Problem 11.3
    def getData(self):
        'returns the concatenation of all text data'
        return self.text



from urllib.request import urlopen
def analyze(url):
    '''prints the frequency of every word in web page url and
       prints and returns the list of http links, in absolute
       format, in it'''
    
    print('\n\nVisiting', url)           # for testing

    # obtain links in the web page
    content = urlopen(url).read().decode()
    collector = Collector(url)
    collector.feed(content)
    urls = collector.getLinks()          # get list of links

    # compute word frequencies
    content = collector.getData()
    freq = frequency(content)

    # print the frequency of every text data word in web page
    print('\n{:45} {:10} {:5}'.format('URL', 'word', 'count'))
    for word in freq:
        print('{:45} {:10} {:5}'.format(url, word, freq[word]))

    # print the http links found in web page
    print('\n{:45} {:10}'.format('URL', 'link'))
    for link in urls:
        print('{:45} {:10}'.format(url, link))

    return urls

from re import findall
def frequency(content):
    '''returns dictionary containing frequencies
       of words in string content'''
    pattern = '[a-zA-Z]+'
    words = findall(pattern, content)
    dictionary = {}
    for w in words:
        if w in dictionary:
            dictionary[w] +=1
        else:
            dictionary[w] = 1
    return dictionary

discovered = set()
def crawl3(startURL):
    'breadth-first search web crawler'

    urlsToVisit = [startURL]         # list of discovered urls yet to be visited
    discovered.add(startURL)         # set of discovered urls

    # while there are unvisited discovered urls 
    while len(urlsToVisit) > 0:

        # visit a url in urlsToVisit in first-in first out order and
        # find links in corresponding content
        url = urlsToVisit.pop(0)
        links = analyze(url)          

        # add every undiscovered link to urlsToVisit and discovered      
        for link in links:
            if link not in discovered:
                urlsToVisit.append(link)
                discovered.add(link)


