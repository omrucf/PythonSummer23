
# Problem CS.55
#
# >>> peg1 = Peg(5)
# >>> peg2 = Peg(5)
# >>> peg3 = Peg(5)
# >>> for i in range(5,0,-1):
# 	peg1.push(Disc(i))
# 
# 	
# >>> hanoi(2, peg1, peg3, peg2)
# >>> move_disk(peg1, peg3)
# >>> hanoi(2, peg2, peg1, peg3)
# >>> move_disk(peg1, peg2)
# >>> hanoi(3, peg3, peg1, peg2)
# >>> move_disk(peg1, peg3)
# >>> hanoi(4, peg2, peg1, peg3)
# >>> 



# Problem CS.56
from turtle import Turtle, Screen
class Bar(Turtle):
    'a vertical bar class, inherits from Turtle'
    pos = -200
    def __init__(self, n):
        'draws a vertical bar of height n at x-coodinate x'

        Turtle.__init__(self, shape='square', visible=False)
        self.penup()              # moves should not be traced
        self.shapesize(n*1.25+0.01,.75,1) # height of bar is function of n
        self.sety(12.5*n)         # bottom of bar is y=0
        self.x = Bar.pos          # x-coord of bar
        self.setx(self.x)         # bar placed at its x-coord
        self.showturtle()         # vertical bar made visible
        Bar.pos += 15

def pattern(n):
    if n==0:
        Bar(0)
    else:
        pattern(n-1)
        Bar(n)
        pattern(n-1)


def patternGUI(n):
    'illustrates the number pattern n'
    screen = Screen()
    pattern(n)
    #screen.bye()


