# Problem CS.14
import turtle
def polygon(n):
    'draw n-sided regular polygon using turtle graphics'
    s = turtle.Screen()
    t = turtle.Turtle()
    for i in range(n):
        t.forward(100)
        t.left(360/n)
    s.bye()


# Problem CS.17
import turtle
def planets():
    'simulates motion of Mercury, Venus, Earth, and Mars'
    s = turtle.Screen()
    mercury = turtle.Turtle(shape='circle')
    venus   = turtle.Turtle(shape='circle')
    earth = turtle.Turtle(shape='circle')
    mars = turtle.Turtle(shape='circle')
    mercury.penup()
    venus.penup()
    earth.penup()
    mars.penup()
    mercury.goto(0,-58)
    venus.goto(0,-108)
    earth.goto(0,-150)
    mars.goto(0,-228)
    mercury.pendown()
    venus.pendown()
    earth.pendown()
    mars.pendown()
    for i in range(365):
        mercury.circle(58,7.5)
        venus.circle(108,3)
        earth.circle(150,2)
        mars.circle(228,1)
    s.bye()
