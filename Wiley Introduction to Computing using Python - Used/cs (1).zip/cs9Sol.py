# Problem CS.50
from calc import Calc
from ch9Sol import Mortgage
class Finances(Frame):
    'Finance app'
    def __init__(self, parent=None):
        'constructor'
        Frame.__init__(self,parent)
        self.pack()
        Finances.make_widgets(self)

    def make_widgets(self):
        'defines Finances widgets'
        Calc(self).pack()
        Mortgage(self).pack()
