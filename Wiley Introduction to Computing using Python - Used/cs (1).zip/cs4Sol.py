# Problem CS.25
def frame(im, ratio):
    width,height = im.size
    r = ratio[0]/ratio[1]
    if width/height >= r:
        w = int(height*r)
        x = (width-w)//2
        box = (x, 0, w+x, height)
    else:
        h = int(width/r)
        y = (height-h)//2
        box = (0, y, width, h+y)
    return im.crop(box)

