

# Exercise 8.22
class oddList(list):
    'list with peculiar iteration loop pattern'

    def __iter__(self):
        'returns list iterator object'
        return ListIterator(self)



class ListIterator(object):
    'peculiar iterator for oddList class'

    def __init__(self, lst):
        'constructor' 
        self.lst = lst
        self.index = 0

    def __next__(self):
        'returns next oddList item'
        if self.index >= len(self.lst):
            raise StopIteration
        res = self.lst[self.index]
        self.index += 3
        return res

