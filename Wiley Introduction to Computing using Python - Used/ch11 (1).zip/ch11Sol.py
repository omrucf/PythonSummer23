# Problem 11.16
from html.parser import HTMLParser
class ListCollector(HTMLParser):

    def __init__(self):
        'initializes parser, the url, and a list'
        HTMLParser.__init__(self)
        self.allLists = []
        self.inList = False
        self.inItem = False
        
    def handle_starttag(self, tag, attrs):
        if tag in {'ul', 'ol'}:
            self.lst = []
            self.inList = True
            self.inItem = False
        elif tag == 'li':
            self.inItem = True

    def handle_data(self, data):
        'collects and concatenates text data'
        if self.inItem:
            self.lst.append(data)

    def handle_endtag(self, tag):
        if tag in {'ul', 'ol'}:
            self.allLists.append(self.lst)
            self.inList = False
        elif tag == 'li':
            self.inItem = False

    def getLists(self):
        return self.allLists



# Problem 11.18
from urllib.request import urlopen
def getContent(url):
    'simple text web browser'
    # get HTML content
    content = urlopen(url).read().decode()

    # remove tags
    pattern = '<[^>]*>'
    tags = findall(pattern, content)
    for tag in tags:
        content = content.replace(tag, ' ')

    # split content into list of lines
    lines = content.split('\n')
    
    prevBlank = True              # initially, previous line was blank

    # print lines stripped; ignore blank lines that follow blank lines
    for line in lines:
        stripped = line.strip()
        if stripped == '' and prevBlank:
            continue
        elif stripped == '' and not prevBlank:
            prevBlank = True     # current line is blank so set prevBlank
        else:
            prevBlank = False    # current line is blank so reset prevBlank
        print(stripped)







# Problem 11.19
from re import findall
def emails(content):
    'return list of email addresses contained in string content'
    # define a simple re for email addresses and find all strings mathcing it
    pattern = '[\w\.&\+\-_]+@[\w\-\.]+'
    duplicates = findall(pattern, content)

    # remove duplicate email addresses
    dictionary = {}
    for email in duplicates:
        if email not in dictionary:
            dictionary[email] = email
    return set(dictionary.keys())

