from math import sqrt
class Point:
    'class that represents a point in the plane'

    # Exercise 8.10 solution
    def distance(self, p):
        'returns distance to point p'
        return sqrt((self.x - p.x)**2 + (self.y - p.y)**2)

    # Exercise 8.12 solution
    def up(self):
        'move up 1 unit'
        self.move(0, 1)

    # Exercise 8.12 solution
    def down(self):
        'move down 1 unit'
        self.move(0, -11)

    # Exercise 8.12 solution
    def left(self):
        'move left 1 unit'
        self.move(-1, 0)

    # Exercise 8.12 solution
    def right(self):
        'move right 1 unit'
        self.move(1, 0)

    def setx(self, xcoord):
        'set x coordinate of point to xcoord'
        self.x = xcoord

    def sety(self, ycoord):
        'set y coordinate of point to ycoord'
        self.y = ycoord

    def get(self):
        'return a tuple with x and y coordinates of the point'
        return (self.x, self.y)

    def move(self, dx, dy):
        'change the x and y coordinates by dx and dy'
        self.x += dx
        self.y += dy



class Animal:
    'represents an animal'

    # Exercise 8.11 solution
    def setAge(self, age):
        'sets animal age'
        self.age = age

    # Exercise 8.11 solution
    def getAge(self):
        'get animal age'
        return self.age

    def setSpecies(self, species):
        'sets the animal species'
        self.spec = species

    def setLanguage(self, language):
        'sets the animal language'
        self.lang = language

    def speak(self):
        'prints a sentence by the animal'
        print('I am a {} and I {}.'.format(self.spec, self.lang))
        


class Rectangle:
    'class that represents rectangles'

    # Exercise 8.13 solution
    def __init__(self, xcoord=1, ycoord=1):
        'init constructor'
        self.x = xcoord
        self.y = ycoord        

    def setSize(self, xcoord, ycoord):
        'constructor'
        self.x = xcoord
        self.y = ycoord

    def perimeter(self):
        'returns perimeter of rectangle'
        return 2 * (self.x + self.y)

    def area(self):
        'returns area of rectangle'
        return self.x * self.y



class Card:
    'represents a playing card'

    # Exercise 8.15 solution 
    def __lt__(self, other):
        'self < other if rank of self < rank of other'
        return self.rank < other.rank

    # Exercise 8.15 solution 
    def __gt__(self, other):
        'self > other if rank of self > rank of other'
        return self.rank > other.rank

    # Exercise 8.15 solution 
    def __le__(self, other):
        'self <= other if rank of self <= rank of other'
        return self.rank <= other.rank

    # Exercise 8.15 solution 
    def __ge__(self, other):
        'self >= other if rank of self >= rank of other'
        return self.rank >= other.rank

    def __init__(self, rank, suit):
        'initialize rank and suit of card'
        self.rank = rank
        self.suit = suit

    def getRank(self):
        'return rank'
        return self.rank

    def getSuit(self):
        'return suit'
        return self.suit    



# Exercise 8.16
class myInt(int):
    'peculiar integer type'

    def __add__(self, other):
        'new add operator behavior'
        return 'Whatever ...'



# Exercise 8.17
class myStr(str):
    'peculiar string type'

    def __add__(self, other):
        'new add operator behavior'
        return len(self) + len(other)

    def __mul__(self, other):
        'new mul operator behavior'
        return len(self) * len(other)



# Exercise 8.18
class myList(list):
    'peculiar list type'

    def sort(self):
        'new sort behavior'
        print('You wish ...')  


# Exercise 8.19
# When repr() is called on queue2, it is the list repr() method that is
# executed. It returns the canonical list representation of queue2. The
# method eval() takes this canonical representation and creates a list
# object out of it. A list object does not support Queue2 method enqueue().
# The solution is to overload methods __repr__() so it returns a canonical
# representation of the Queue2 object, one that method eval() will evaluate
# as a Queue2 object. See below
class Queue2(list): 
    'a queue class, subclass of list'

    # Exercise 8.19 solution
    def __repr__(self):
        'return canonical string representation of queue'
        return 'Queue2({})'.format(list.__repr__(self))

    def isEmpty(self):
        'returns True if queue is empty, False otherwise'
        return (len(self) == 0)

    def dequeue(self):
        'remove and return item at front of queue'
        return self.pop(0)

    def enqueue (self, item):
        'insert item at rear of queue'
        return self.append(item)



# Problem 8.20
class BankAccount(object):
    'a bank account class'

    def __init__(self, initial=0):
        'constructor'
        self.b = initial

    def withdraw(self, amount):
        'withdraws amount'
        self.b -= amount

    def deposit(self,amount):
        'deposits amount'
        self.b += amount

    def balance(self):
        'returns balance'
        return self.b



# Problem 8.21
import math
class Polygon(object):
    'regular polygon class'

    def __init__(self, n, s):
        'constructs an n-sided polygon with side length s'
        self.n = n
        self.s = s

    def perimeter(self):
        'returns polygon perimeter'
        return self.n*self.s

    def area(self):
        'returns polygon area'
        return (self.n*self.s**2)/(4*math.tan(math.pi/self.n))



# Problem 8.22
class Worker(object):
    'worker class'
    def __init__(self, name, rate):
        'constructs worker object with associated name and pay rate'
        self.name = name
        self.rate = rate

    def changeRate(self, newRate):
        'changes worker rate'
        self.rate = newRate

    def pay(self,hours):
        'returns worker pay'
        print('Not implemented')
        

class HourlyWorker(Worker):
    'hourly worker class'

    def pay(self, hours):
        'returns hourly worker pay'
        if hours > 40:
            return 40*self.rate + (hours-40)*2*self.rate
        else:
            return hours*self.rate

class SalariedWorker(Worker):
    'salaried work class'

    def pay(self, hours=None):
        'returns salaried worker pay'
        return 40*self.rate



# Problem 8.24
from time import localtime
class Person(object):
    'person class'

    def __init__(self, name, birthYear):
        'constructs person with given name and birth year'
        self.personName = name
        self.birthYear = birthYear

    def age(self):
        'computes and returns person age'
        return localtime()[0] - self.birthYear

    def name(self):
        'returns person name'
        return self.personName



# Problem 8.25
class Textfile(object):
    ' a class that provides tools to analyze a text file'

    files = []                     # list of all textfile objects

    def __init__(self, filename):
        '''constructor that associates textfile object with
           file named filename'''
        self.name = filename
        handle = open(filename)
        self.content = handle.read()
        handle.close()
        self.files.append(filename)

    def nchars(self):
        'returns the number of characters in the file'
        return len(self.content)

    def nwords(self):
        'returns the number of words in the file'
        return len(self.content.split())

    def nlines(self):
        'returns the number of lines in the file'
        return self.content.count('\n')+1

    def read(self):
        'returns the content of the file as a string'
        return self.content

    def readlines(self):
        'returns the content of the file as a list of lines'
        return self.content.split('\n')

    def grep(self, target):
        'prints out all lines containing string target'
        lines = self.readlines()
        for i in range(len(lines)):
            if lines[i].find(target) >= 0:
                print('{}: {}'.format(i, lines[i]))



# Problem 8.29
class Hand(object):
    'represents a hand of playing cards'

    def __init__(self, player):
        'initializes player ID and initial empty hand'
        self.player = player
        self.hand = []

    def addCard(self, card):
        'adds card to hand'
        self.hand.append(card)

    def showHand(self):
        'prints player ID and hand'
        print('{}:'.format(self.player), end='')
        for card in self.hand:
            rank = card.getRank()
            suit = card.getSuit()
            print('{:>4} {}'.format(rank, suit), end = '')



# Problem 8.31
import time
class Date(object):
    'date format class'

    def __init__(self):
        'constructs object associated with current date'
        self.time = time.localtime()

    def display(self, form):
        'displays date in specified format form'
        if form == 'MDY':
            return time.strftime('%m/%d/%y', self.time)
        elif form == 'MDYY':
            return time.strftime('%m/%d/%Y', self.time)
        elif form == 'DMY':
            return time.strftime('%d/%m/%y', self.time)
        elif form == 'DMYY':
            return time.strftime('%d/%m/%Y', self.time)
        elif form == 'MODY':
            return time.strftime('%b %d, %Y', self.time)




# Problem 8.32
from random import randrange
class Craps(object):
    'a craps game simulation'

    def __init__(self):
        'constructor that starts a game of craps'
        self.initial = randrange(1,7) + randrange(1,7)
        if self.initial in [7,11]:
            print('Thow total: {}. You won!'.format(self.initial))
        elif self.initial in [2,3,12]:
            print('Thow total: {}. You lost!'.format(self.initial))
        else:
            print('Thow total: {}. Throw for Point.'.format(self.initial))

    def forPoint(self):
        'throws for point'
        tmp = randrange(1,7) + randrange(1,7)
        if tmp == self.initial:
            print('Thow total: {}. You won!'.format(tmp))
        elif tmp == 7:
            print('Thow total: {}. You lost!'.format(tmp))
        else:
            print("Throw total: "+str(tmp)+". Throw for Point.")
    


# Problem 8.33
class pseudorandom(object):
    'linear congruential pseudorandom number generator'

    def __init__(self, seed, multiplier, increment, modulus):
        '''contructs a generator with given seed, multiplier,
           increment, and modulus'''
        self.seed = seed
        self.multiplier = multiplier
        self.increment = increment
        self.modulus = modulus

    def next(self):
        'returns next pseudorandom number'
        self.seed = (self.multiplier*self.seed+self.increment)%self.modulus
        return self.seed



# Problem 8.34
class Stat(object):
    'container for numbers that supports statistical methods'

    def __init__(self):
        'constructor'
        self.l = []

    def add(self, value):
        'adds value to Stat container'
        self.l.append(value)

    def min(self):
        'returns minimum value in container'
        return min(self.l)

    def max(self):
        'returns maximum value in container'
        return max(self.l)

    def mean(self):
        'returns average of items in container'
        return self.sum()/float(len(self))

    def sum(self):
        'returns sum of values in container'
        return sum(self.l)

    def __contains__(self, value):
        'returns True if in the container'
        return value in self.l

    def clear(self):
        'Empties the container'
        self.l = []

    def __len__(self):
        'returns number of items in container'
        return(len(self.l))



# Problem 8.35
class Stack(object):
    'classic stack class'

    def __init__(self):
        'constructor initializes empty stack'
        self.s = []

    def pop(self):
        'removes and returns top item in stack'
        return self.s.pop()

    def push (self, item):
        'pushes item into stack'
        return self.s.append(item)

    def isEmpty(self):
        'checks whether stack is empty'
        return (len(self) == 0)

    def __len__(self):
        'returns length of stack'
        return len(self.s)

    def __repr__(self):
        'returns a string representation of stack object'
        return repr(self.s)



# Problem 8.36
# Priority Queue using sorted, in non-increasing order, list invariant
# (with O(1) removeMin).
# The implementation of method insert() is made to be simple rather
# than efficient
class PriorityQueue(object):
    'Priority queue class'

    def __init__(self):
        'constructor initializes empty priority queue'
        self.l = []

    def insert(self, item):
        'inserts item into priority queue'
        self.l.append(item)
        self.l.sort(reverse=True)

    def min(self):
        'returns minimum item in priority queue'
        return self.l[-1]

    def removeMin(self):
        'removes minimum item in priority queue'
        self.l.pop()

    def __len__(self):
        'returns size of priority queue'
        return len(self.l)

    def isEmpty(self):
        'checks whether priority queue is empty'
        return len(self) == 0


# Priority Queue using unsorted list invariant (with O(1) insert)
# The implementation of method removeMin() is made to be simple rather
# than efficient
class PriorityQueue2(object):
    'Priority queue class'

    def __init__(self):
        'constructor initializes empty priority queue'
        self.l = []

    def insert(self, item):
        'inserts item into priority queue'
        self.l.append(item)

    def min(self):
        'returns minimum item in priority queue'
        return min(self.l)

    def removeMin(self):
        'removes minimum item in priority queue'
        self.l.remove(min(self.l))

    def __len__(self):
        'returns size of priority queue'
        return len(self.l)

    def isEmpty(self):
        'checks whether priority queue is empty'
        return len(self) == 0



# Problem 8.37
class Square(Polygon):
    'square class'

    def __init__(self, s):
        'constructor that initializes the side length of a square'
        Polygon.__init__(self, 4, s)

    def area(self):
        'returns square area'
        return self.s**2

from math import sqrt
class Triangle(Polygon):
    def __init__(self, s):
        'constructor that initializes the side length of an equilateral triangle'
        Polygon.__init__(self, 3, s)

    def area(self):
        'returns triangle area'
        return sqrt(3)*self.s**2/4



# Problem 8.38
class Instructor(Person):
    'instructor class'

    def __init__(self,name,birthYear,degree):
        'constructs instructor with given name, birth year, and degree'
        Person.__init__(self, name, birthYear)
        self.d = degree

    def degree(self):
        'returns instructor degree'
        return self.d

class Student(Person):
    'student class'

    def __init__(self,name,birthYear,major):
        'constructs student with given name, birth year, and major'
        Person.__init__(self, name, birthYear)
        self.m = major

    def major(self):
        'returns student major'
        return self.m



# Problem 8.39
class Animal(object):
    'animal class'
    def speak(self):
        print('')

class Mammal(Animal):
    'mammal class'
    def speak(self):
        print('Mama!')

class Cat(Mammal):
    'cat class'
    def speak(self):
        print('Meeow!')

class Dog(Mammal):
    'dog class'
    def speak(self):
        print('Wooof!')

class Primate(Mammal):
    'primate class'
    def speak(self):
        print('Boooh')

class Hacker(Primate):
    'hacker class'
    def speak(self):
        print('Hello World!')



# Problem 8.40
class BankAccount2(object):
    'a second bank account class'

    def __init__(self, initial=0):
        'constructor; raises ValueError exception if initial balance is negative'
        if initial < 0:
            raise ValueError('Negative balance')
        self.b = initial

    def withdraw(self, amount):
        'withdraws amount; raises ValueError exception if resulting balance is negative'
        if self.b - amount<0:
            raise ValueError('Overdraft')
        self.b -= amount

    def deposit(self, amount):
        'deposits amount; raises ValueError exception if amount is negative'
        if amount < 0:
            raise ValueError('Negative deposit')
        self.b += amount

    def balance(self):
        'returns balance'
        return self.b



# Problem 8.41
class NegativeBalanceError(Exception):
    'negative balance exception'

    def __init__(self,value):
        self.value = value

    def __str__(self):
        return 'Account created with negative balance ' + repr(self.value)

class OverdraftError(Exception):
    'overdraft exception'

    def __init__(self,value):
        self.value = value

    def __str__(self):
        return 'Operation would result in negative balance ' + repr(self.value)

class DepositError(Exception):
    'negative deposit exception'

    def __init__(self,value):
        self.value = value

    def __str__(self):
        return 'Negative deposit ' + repr(self.value)

class BankAccount3(object):
    'a third bank account class'

    def __init__(self, initial=0):
        'constructor; raises NegativeBalanceError exception if initial balance is negative'
        if initial < 0:
            raise NegativeBalanceError(initial)
        self.b = initial

    def withdraw(self, amount):
        'withdraws amount; raises OverdraftError exception if resulting balance is negative'
        if self.b-amount<0:
            raise OverdraftError(self.b-amount)
        self.b -= amount

    def deposit(self,amount):
        'deposits amount raises DepositError exception if amount is negative'
        if amount < 0:
            raise DepositError(amount)
        self.b += amount

    def balance(self):
        'returns balance'
        return self.b

