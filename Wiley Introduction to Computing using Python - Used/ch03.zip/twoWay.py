temp = eval(input('Enter the current temperature: '))

if temp > 86:

    print("It is hot!")
    print('Be sure to drink liquids.')

else:

    print('It is not hot.')
    print('Bring a jacket.')

print('Goodbye.')
