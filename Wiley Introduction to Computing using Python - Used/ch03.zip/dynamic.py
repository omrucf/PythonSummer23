s = input("Enter square or cube: ")
if s == 'square':
    def f(x):
        return x*x
else:
    def f(x):
        return x*x*x
