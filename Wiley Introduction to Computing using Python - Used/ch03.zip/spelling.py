name = input('Enter a word: ')
print('The word spelled out: ')

for char in name:
    print(char)
