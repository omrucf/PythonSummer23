def f(x):
    'returns x**2 + 1'
    res = x**2 + 1  # compute x**2 + 1 and store value in res
    return res      # return value of res


def squareSum(x, y):
    'returns x**2 + y**2'
    return x**2 +  y**2


def hello(name):
    'a personalized hello function'
    print('Hello, '+ name + '!')


def g(x):
    x = 5


def h(lst):
    lst[0] = 5




##################################
# Solutions to Practice Problems #
##################################




# Practice Problem 3.8
import math
def perimeter(radius):
    'returns perimeter of circle of given radius'
    return 2 * math.pi * radius


# Practice Problem 3.9
def average(x, y):
    'returns average of x and y'
    return (x + y) / 2


# Practice Problem 3.10
def noVowel(s):
    'return True if string s contains no vowel, False otherwise'
    for c in s:
        if c in 'aeiouAEIOU':
            return False
    return True

 
# Practice Problem 3.11
def allEven(numList):
    'return True is all integers in numList are even, False otherwise'
    for num in numList:
        if num%2 != 0:
            return False
    return True


# Practice Problem 3.12
def negatives(lst):
    'prints the negative numbers in list lst'
    for i in lst:
        if i < 0:
            print(i)


# Practice Problem 3.16
def swapFL(lst):
    'swaps first and last item in list lst'
    lst[0], lst[-1] = lst[-1], lst[0]
