# Exercise 6.11
def easyCrypto(s):
    '''prints the following encryption of s: Every character at an odd
       position i in the alphabet is encrypted with the character at
       position i + 1, and every character at an even position i will
       be encrypted with the character at position i − 1'''
    res = ''
    for c in s:
        if not c.isalpha():
            res.append(c)
            continue
        if c.islower():
            base = 'a'
        else:
            base = 'A'
        if (ord(c)-ord(base))%2 == 0:
            res += chr(ord(c)+1)
        else:
            res += chr(ord(c)-1)
    return res



# Exercise 6.12
def letter2number(lgrade):
    'returns the number grade corresponding to the letter grade lgrade'
    grades = {'A':4.0,
              'A-':3.7,
              'B+':3.3,
              'B':3.0,
              'B-':2.7,
              'C+':2.3,
              'C':2.0,
              'C-':1.7,
              'D+':1.3,
              'D':1.0,
              'F':0.0
              }
    return grades[lgrade]


    
# Exercise 6.15
def lookup(phonebook):
    '''implements interactive phone book service using the input
       phonebook dictionary'''
    while True:
        first = input('Enter the first name: ')
        last = input('Enter the last name: ')

        person = (first, last)    # construct the key

        if person in phonebook:   # if key is in dictionary
            for number in phonebook[person]: # print all numbers
                print(number)
        else:                     # if key not in dictionary
            print('The name you entered is not known.')


    
# Exercise 6.17
def hexASCII():
    '''prints correspondence between the lowercase characters in the
       alphabet and the hexadecimal representation of their ASCII code'''
    for i in range(97,123):
        print('{}:{:x}'.format(chr(i),i),end=' ')



# Exercise 6.18
import random
def coin():
    '''returns 'Heads' or 'Tails' with equal probability'''
    lst = ['Heads', 'Tails']
    return random.choice(lst)



# Problem 6.20
def reverse(phonebook):
    '''phonebook is a dictionary mapping names (keys) to
       phone numbers (values); function returns another dictionary
       representing the reverse phone book mapping phone numbers
       (keys) to the names (values)'''
    reversebook = {}
    for key in phonebook:
        reversebook[phonebook[key]] = key
    return reversebook



# Problem 6.21
def ticker(filename):
    '''file filename contains company names and stock (ticker) symbols
       in the format:
           company 1 name
           company 1 stock symbol
           company 2 name
           company 2 stock symbol
           ...
        function provides an interface through which the stock symbol
        for a given company can be obtained'''
    infile = open(filename)
    lines = infile.readlines()
    infile.close()
    d = {}
    for index in range(0, len(lines)-1, 2):
        d[lines[index][:-1]] = lines[index+1][:-1]
    while True:
        company = input('Enter Company name: ')
        print('Ticker symbol: ' + d[company])



# Problem 6.22
def mirror(word):
    '''returns mirror image of word but if it can be represented
       using letters in the alphabet'''
    d = {'b':'d', 'd':'b', 'i':'i', 'o':'o', 'v':'v', 'w':'w', 'x':'x'}
    res = ''
    for c in word:
        if c in d:
            res = d[c]+res
        else:
            return 'INVALID'
    return res



# Problem 6.23
import string
def scaryDict(filename):
    '''prints, and writes to file dictionary.txt, all the words
       in file filename, in alphabetical order; one- and two-letter
       words are ignored'''
    # get file content in lowercase
    infile = open(filename)
    content = infile.read().lower()
    infile.close()

    # remove punctuation and obtain list of words
    punctuation = '.,\"!()-0123456789;:\`!?[]_'   
    table = str.maketrans(punctuation, len(punctuation)*' ' )
    words = content.translate(table).split()

    # remove duplicates and sort the unique words
    dictionary = list(set(words))
    dictionary.sort()

    # print dictionary and write it to a file
    outfile = open('dictionary.txt', 'w')
    for w in dictionary:
        if len(w) > 2:
            outfile.write(w + '\n')
            print(w)
    outfile.close()



# Problem 6.24
def names():
    '''opens interface that allows user to enter the first name
       of a student in a class; when the user enters the empty string,
       the function prints every unqie name entered and the number of
       students with that name'''
    d = {}
    while True:
        name = input("Enter next name: ")
        if name == '':
            break
        if name in d:
            d[name] += 1
        else:
            d[name] = 1
    for name in d:
        if d[name] > 1:
            print("There are", d[name], "students named", name)
        else:
            print("There is 1 student named", name)



# Problem 6.25
def different(t):
    'returns the number of distinct entries in two-dimensional list table'
    d = {}
    for row in t:
        for item in row:
            if item not in d:
                d[item] = item
    return len(d)


# Problem 6.26
def week():
    '''interactive interface that prints the day of the week
       corresponding to a two-letter abbreviation'''
    d = {'Mo':'Monday', 'Tu':'Tuesday', 'We':'Wednesday', 'Th':'Thursday', 'Fr':'Friday', 'Sa':'Saturday', 'Su':'Sunday'}
    while True:
        day = input('Enter day abbreviation: ')
        print(d[day])


# Problem 6.27
def index(filename, words):
    '''prints a mapping of words from list words to all the line
       numbers of lines in which the words appear in file filename'''
    infile = open(filename)

    # initialize dictionary mapping words to lists of line numbers
    d = {}
    for word in words:
        d[word] = []

    lineNum = 0                  # line number

    while True:
        line = infile.readline() # read line and increment line number
        lineNum += 1
        if line == '':           # end of file
            break
        for c in '!-_:;\'",.?':  # remove punctuation
            line = line.replace(c, ' ')
        wordList = line.split()  # obtain list of words

        # for every word in words, if word in line, update dictionary
        for word in words:
            if word in wordList:
                d[word].append(lineNum)
    infile.close()

    # output line index
    for word in d:
        print('{:10}{}'.format(word, d[word][0]), end='')
        for index in range(1, len(d[word])):
            print(', {}'.format(d[word][index]), end='')
        print()



# Problem 6.29
def networks(n, friendsList):
    '''friendlyList is a list representing a binary relation on
       set {0, 1, 2, ..., n-1}; function computes and prints the
       equivalence classes of the relations transitive closure'''
    # defining a set for each i = 0, 1, ..., n-1
    sets = []
    for i in range(n):
        sets.append({i})

    # for every pair (i, j) in friendList, replace
    # sets containing them with their union
    for friends in friendsList:
        union = set()
        i = 0
        while i < len(sets):
            if (friends[0] in sets[i]) or (friends[1] in sets[i]):
                union |= sets[i]
                sets.pop(i)
            else:
                i += 1
        sets.append(union)

    # print equivalence classes
    for i in range(len(sets)):
        print('Social network {} is {}'.format(i, sets[i]))


# Problem 6.30
# Assumes that module ch5Sol.py is in the same directory as ch6Sol.py
import random, ch5Sol
def simul(n):
    choices = ['R', 'P', 'S']
    res = 0
    for i in range(n):
        play1 = random.choice(choices)
        play2 = random.choice(choices)
        res += ch5Sol.rps(play1, play2) # using function rps() from Problem 5.26
    if res < 0:
        print('Player 1')
    elif res > 0:
        print('Player 2')
    else: # res == 0
        print('Tie')


# Problem 6.31
from random import randint
def craps():
    'simulates a game of craps'
    roll = randint(1,6) + randint(1,6)
    if roll in [7, 11]:
        return 1
    elif roll not in [2, 3, 12]:
        return forPoint(roll)
    else: # roll in [2, 3, 12]
        return 0

def forPoint(initialRoll):
    'roll for point'
    while True:
        roll = randint(1,6) + randint(1,6)
        if roll == 7:
            return 0
        elif roll == initialRoll:
            return 1

def testCraps(n):
    'simulates n games of craps and returns the fraction of games won'
    wins = 0
    for i in range(n):
        wins += craps()
    return wins/float(n)



# Problem 6.32
from random import randrange
def manhattan(r, c):
    '''simulates a random walk starting in the center of a r x c grid and
       prints the number of times each intersection has been visited'''
    # create a r x c table of zeros
    table = []
    for i in range(r):
        table.append(c*[0])

    # initialize starting position and its visit count
    x, y = r//2, c//2
    table[x][y] += 1

    # perform the random walk
    while True:
        direc = randrange(1,5)
        if direc == 1:     # go east
            x += 1
        elif direc == 2:   # go west
            x -= 1
        elif direc == 3:   # go north
            y += 1
        elif direc == 4:   # go south
            y -= 1
        if 0 <= x < r and 0 <= y < c: # increment visit count
            table[x][y] += 1
        else:        
            for i in range(len(table)):
                print(table[i])
            break



# Problem 6.33
from random import randrange
def diceprob(r):
    '''simulates repeated rolls of a pair of dice until
       100 rolls of r have been obtained; the number of
       rolls is then printed'''
    rolls = 0
    count = 0
    while count < 100:
        roll = randrange(1,7)+randrange(1,7)
        rolls += 1
        if roll == r:
            count += 1
    print('It took {} rolls to get 100 rolls of {}'.format(rolls, r))



# Problem 6.35
from random import randint
def game(n):
    'an app to teach simple arithmetic'
    count = 0
    for i in range(n):
        x, y = randint(0,9), randint(0,9)
        print(x, ' + ', y, ' = ')
        ans = eval(input("Enter answer: " ))
        if ans == x+y:
            print("Correct.")
            count += 1
        else:
            print("Incorrect.")
    print("You got", count, "correct answers out of", n)



# Problem 6.36
def caesar(key, filename):
    '''encodes file filename using the Caesar cipher and given key and
       prints and writes the encrypted content into file cipher.txt'''
    infile = open(filename)
    content = infile.read()
    infile.close()
    
    newcontent = ''
    for c in content:
        if 'A' <= c <= 'Z':
            if ord(c) + key > 90:
                newcontent = newcontent+chr(((ord(c)+key) % 91) + 65)
            else:
                newcontent = newcontent+chr(ord(c)+key)
        elif 'a' <= c <= 'z':
            if ord(c) + key > 122:
                newcontent = newcontent+chr(((ord(c)+key) % 123) + 97)
            else:
                newcontent = newcontent+chr((ord(c)+key))
        else:
            newcontent = newcontent+c
    outfile = open('cipher.txt', 'w')
    outfile.write(newcontent)
    outfile.close()
    return newcontent



# Problem 6.37
def zipf(filename):
    '''prints the value freq(w) ∗ k for the first 10 most frequent
       words w in file filename'''
    infile = open(filename)
    content = infile.read()
    infile.close()

    # remove punctuation and obtain list of words
    punctuation = '!$%&*()-+={}[];:"\'<>?,./'  
    table = str.maketrans(punctuation, len(punctuation)*' ' )
    words = content.translate(table).split()

    # compute word frequencies
    count = {}
    for word in words:
        if word.lower() in count:
            count[word.lower()] +=1
        else:
            count[word.lower()] = 1

    # sort the frequencies
    values = list(count.values())
    values.sort()

    # print freq(w) * i for the 10 most frequent words
    for i in range(1,11):
        print(values[-i]*i/len(words)) 
    

