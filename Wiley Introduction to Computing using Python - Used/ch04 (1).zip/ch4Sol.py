# Problem 4.22
def month(num):
    'return the three-character abbreviation of num-th month'
    months = 'JanFebMarAprMayJunJulAugSepOctNovDec'
    return months[3*(num-1):3*num]



# Problem 4.23
def average():
    '''requests a sentence from the user and returns
       the average length of a word in the sentence'''
    sentence = input('Enter a sentence: ')
    numWords = len(sentence.split())
    return (len(sentence)-numWords+1)/numWords



# Problem 4.24
def cheer(s):
    'prints a cheer for team s'
    print('How do you spell winner?')
    print('I know, I know!')
    for c in s:
        print(c.upper(), end=' ')
    print('!')
    print("And that's how you spell winner!")
    print('Go ' + s + '!')



# Problem 4.25
def vowelCount(s):
    'counts and prints the number of occurrences of each vowel in s'
    print('a, e, i, o, and u appear, respectively', end='')
    vowels = 'aeiou'
    for vowel in vowels:
        print(', {}'.format(s.count(vowel)), end='')
    print(' times.')



# Problem 4.26
def crypto(filename):
    '''opens and prints file filename with the modification that
       every occurrence of string 'secret' is replaced with 'xxxxxx'
    '''
    infile = open(filename)
    content = infile.read()
    infile.close()
    print(content.replace('secret', 'xxxxxx'))



# Problem 4.27
def fcopy(original, copy):
    'creates a copy of file original named copy'
    infile = open(original)
    content = infile.read()
    infile.close()
    outfile = open(copy, 'w')
    outfile.write(content)
    outfile.close()



# Problem 4.28
def links(filename):
    'returns the number of hyperlinks in (HTML) file filename'
    infile = open(filename)
    content = infile.read()
    infile.close()
    print(content.count('</a>'))



# Problem 4.29
def stats(filename):
    ' prints the number of lines, words, and characters in file filename'
    # get file content
    infile = open(filename)
    content = infile.read()
    infile.close()

    # replace punctuation with blank spaces and obtain list of words
    table = str.maketrans('.,;!?:\n', 7*' ' )
    words = content.translate(table).split()

    print('line count: {}'.format(content.count('\n')))
    print('word count: {}'.format(len(words)))
    print('character count: {}'.format(len(content)))



# Problem 4.30
def distribution(filename):
    '''file filename contains letter grades separated by blanks;
       the function prints the distribution of grades'''
    # get file content
    infile = open(filename)
    content = infile.read()
    infile.close()

    # split content into a list of grades
    grades = content.split()

    # for every grade, print the number of times it occurs if any
    for grade in ['A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'F']:
        num = grades.count(grade)
        if num > 0:
            if num == 1:
                print('1 student  got', grade)
            else:
                print('{} students got {}'.format(num, grade))



# Problem 4.31
def duplicate(filename):
    'checks whether file filename contains duplicate words'
    # get file content
    infile = open(filename)
    content = infile.read()
    infile.close()

    # replace punctuation with blank spaces and obtain list of words
    table = str.maketrans('.,;!?:\n', 7*' ' )
    words = content.translate(table).split()

    # for every word, check if it occurs more than once; if so, return True
    for word in words:
        if words.count(word) > 1:
            return True

    # no word occured more than once, so return False
    return False



# Problem 4.32
def censor(filename):
    '''copies file filename with the modification that every
    occurrence of a four-letter word is replaced with 'xxxx'
    '''
    # get file content
    infile = open(filename)
    content = infile.read()
    infile.close()

    # replace punctuation with blank spaces and obtain list of words
    table = str.maketrans('.,;!?:\n', 7*' ' )
    words = content.translate(table).split()

    # replace each four-letter word with 'xxxx' 
    for word in words:
        if len(word) == 4:
            # replace four-letter word if it is delimited by blanks 
            content = content.replace(' '+word+' ', ' xxxx ')

    # write new content to file
    outfile = open('censored.txt', 'w')
    outfile.write(content)
    outfile.close()
