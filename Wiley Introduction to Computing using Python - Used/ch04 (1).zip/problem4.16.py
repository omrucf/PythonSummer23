first = input('Enter first word: ')
second = input('Enter second word: ')
third = input('Enter third word: ')
if first < second < third:
    print(True)
