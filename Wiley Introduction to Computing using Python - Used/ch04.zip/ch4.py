def growthrates(n):
    'prints values of below 3 functions for i = 1, ..., n'
    print(' i   i**2   i**3   2**i')
    formatStr = '{0:2d} {1:6d} {2:6d} {3:6d}'
    for i in range(2, n+1):
        print(formatStr.format(i, i**2, i**3, 2**i))



def numChars(filename):
    'returns the number of characters in file filename'
    infile = open(filename, 'r')
    content = infile.read()
    infile.close()

    return len(content)


def numWords(filename):
    'returns the number of words in file filename'
    infile = open(filename, 'r')
    content = infile.read()       # read the file into a string
    infile.close()

    wordList = content.split()    # split file into list of words
    print(wordList)               # print list of words too
    return len(wordList)



def numLines(filename):
    'returns the number of lines in file filename'
    infile = open(filename, 'r')   # open the file and read it
    lineList = infile.readlines()  # into a list of lines
    infile.close()

    print(lineList)                # print list of lines
    return len(lineList)






##################################
# Solutions to Practice Problems #
##################################


# Practice Problem 4.4
def even(n):
    '''prints numbers between 2 and n that
     are divisible by 2 or 3'''
    for i in range(2, n+1):
        if i%2 == 0 or i%3 == 0:
            print(i, end=', ')


# Practice Problem 4.6
def roster(students):
    'prints average grade for a roster of students'
    print('Last      First     Class      Average Grade')
    for student in students:
        print('{:10}{:10}{:10}{:8.2f}'.format(student[0],
                student[1], student[2], student[3]))


# Practice Problem 4.8
def stringCount(filename, target):
    'returns the number of occurences of target in file filename'
    infile = open(filename)
    content = infile.read()
    infile.close()
    return content.count(target)


# Practice Problem 4.9
def words(filename):
    'returns the list of words in file filename'
    infile = open(filename, 'r')
    content = infile.read()
    infile.close()
    table = str.maketrans('!,.:;?', 6*' ')
    content = content.translate(table)
    content = content.lower()
    return content.split()


# Practice Problem 4.10
def myGrep(filename, target):
    'prints every line of file filename containing string target'
    infile = open(filename)
    for line in infile:
        if target in line:
            print(line, end='')


